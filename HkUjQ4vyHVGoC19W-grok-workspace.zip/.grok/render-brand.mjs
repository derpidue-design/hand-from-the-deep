import { chromium } from "playwright";
import { pathToFileURL } from "node:url";
import { join } from "node:path";

const root = "/workspace/.grok";

async function shot(page, file, width, height, out) {
  await page.setViewportSize({ width, height });
  await page.goto(pathToFileURL(join(root, file)).href, { waitUntil: "load" });
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(80);
  await page.screenshot({ path: join(root, out), type: "png" });
}

const browser = await chromium.launch();
const page = await browser.newPage({ deviceScaleFactor: 1 });
await shot(page, "og-card.html", 1200, 630, "og-raw.png");
await shot(page, "x-banner.html", 1200, 264, "banner-raw.png");
await browser.close();
console.log("rendered og-raw.png and banner-raw.png");
