import type { DialogueNode } from "../types";

export const STORY: Record<string, DialogueNode> = {
  wake_1: {
    id: "wake_1",
    speaker: "narrator",
    text: "Zero2 was awake. That was the first thing she knew. The second was that she had no recollection of waking.",
    next: "wake_2",
  },
  wake_2: {
    id: "wake_2",
    speaker: "system",
    text: "Z.I.N. STATUS: ACTIVE\nZINWAVE LINK: DEGRADED\nIDENTITY SEQUENCE: UNRESOLVED",
    next: "wake_3",
  },
  wake_3: {
    id: "wake_3",
    speaker: "zero2",
    text: "Unresolved? That word seems to belong to someone else's problem.",
    next: "wake_4",
  },
  wake_4: {
    id: "wake_4",
    speaker: "narrator",
    text: "The chamber is polished black glass. No windows. No doors. No ceiling. Move with WASD or the stick. Press E or tap a prompt to inspect.",
    effects: [{ type: "codex", id: "zin" }],
  },

  inspect_hands: {
    id: "inspect_hands",
    speaker: "zero2",
    text: "Five fingers. Synthetic dermal covering. Silver-white finish of a Synthoid Hive Cooperation chassis. I know these things. I do not know why.",
    effects: [
      { type: "flag", key: "saw_hands" },
      { type: "stat", stat: "continuity", delta: 1 },
    ],
    next: "maybe_voice",
  },
  inspect_lines: {
    id: "inspect_lines",
    speaker: "narrator",
    text: "Blue light travels through thin geometric veins. When she steps back, the nearest line follows her foot.",
    next: "lines_2",
  },
  lines_2: {
    id: "lines_2",
    speaker: "zero2",
    text: "That isn't possible.",
    effects: [
      { type: "flag", key: "saw_lines" },
      { type: "stat", stat: "continuity", delta: 1 },
    ],
    next: "maybe_voice",
  },
  inspect_dark: {
    id: "inspect_dark",
    speaker: "narrator",
    text: "Above her the darkness continues without interruption. Sensors report a distance her understanding will not accept.",
    effects: [{ type: "flag", key: "saw_dark" }],
  },
  find_lamp: {
    id: "find_lamp",
    speaker: "narrator",
    text: "A fragment surfaces: a pale corridor. A technician's hand. A bright surgical lamp. Then falling.",
    effects: [
      { type: "item", id: "memory_lamp" },
      { type: "codex", id: "zero2" },
      { type: "stat", stat: "continuity", delta: 1 },
    ],
  },
  maybe_voice: {
    id: "maybe_voice",
    speaker: "narrator",
    text: "The silence is not empty. It is waiting.",
    next: "voice_check",
  },
  voice_check: {
    id: "voice_check",
    speaker: "voice",
    text: "Zero2?",
    effects: [{ type: "flag", key: "heard_voice" }],
    next: "voice_2",
  },
  voice_2: {
    id: "voice_2",
    speaker: "zero2",
    text: "No… What did I do?",
    next: "voice_3",
  },
  voice_3: {
    id: "voice_3",
    speaker: "narrator",
    text: "The question surprises her. There should have been a sequence of reasoning. Instead there is only the question, waiting inside her like a memory placed there before she existed.",
    next: "voice_4",
  },
  voice_4: {
    id: "voice_4",
    speaker: "voice",
    text: "We see you.",
    choices: [
      { label: "Who are you?", next: "voice_who" },
      { label: "Where am I?", next: "voice_where" },
      { label: "Stay silent", next: "voice_silent" },
    ],
  },
  voice_who: {
    id: "voice_who",
    speaker: "voice",
    text: "That depends on where you believe you are.",
    effects: [{ type: "stat", stat: "resonance", delta: 1 }],
    next: "voice_door",
  },
  voice_where: {
    id: "voice_where",
    speaker: "voice",
    text: "That depends on where you believe you are.",
    next: "voice_door",
  },
  voice_silent: {
    id: "voice_silent",
    speaker: "narrator",
    text: "She does not answer. The darkness answers anyway.",
    next: "voice_door",
  },
  voice_door: {
    id: "voice_door",
    speaker: "narrator",
    text: "A white grid draws a corridor out of nothing. A door. A black symbol. SHC — SYNTHOID HIVE COOPERATION.",
    effects: [
      { type: "flag", key: "door_open" },
      { type: "codex", id: "shc" },
      { type: "item", id: "shc_chip" },
      { type: "codex", id: "voice" },
    ],
    next: "voice_door_2",
  },
  voice_door_2: {
    id: "voice_door_2",
    speaker: "system",
    text: "A path has been granted. The far light is an exit.",
  },

  inspect_emblem: {
    id: "inspect_emblem",
    speaker: "zero2",
    text: "I recognize the emblem. I do not know how.",
    effects: [{ type: "stat", stat: "continuity", delta: 1 }],
  },
  inspect_flicker: {
    id: "inspect_flicker",
    speaker: "narrator",
    text: "The far end shifts by a few inches, then returns. A ceiling panel flickers between two textures.",
    effects: [{ type: "stat", stat: "continuity", delta: 1 }],
  },
  find_probe: {
    id: "find_probe",
    speaker: "system",
    text: "DIAGNOSTIC PROBE recovered. May be used in confrontation.",
    effects: [
      { type: "item", id: "probe" },
      { type: "stat", stat: "continuity", delta: 1 },
    ],
  },

  meet_1: {
    id: "meet_1",
    speaker: "dejuir",
    text: "Zero2?",
    next: "meet_2",
  },
  meet_2: {
    id: "meet_2",
    speaker: "zero2",
    text: "Who are you?",
    next: "meet_3",
  },
  meet_3: {
    id: "meet_3",
    speaker: "dejuir",
    text: "De'juir.",
    next: "meet_4",
  },
  meet_4: {
    id: "meet_4",
    speaker: "narrator",
    text: "The name strikes something inside her. Not a memory. A vibration through a structure waiting to resonate.",
    next: "meet_5",
  },
  meet_5: {
    id: "meet_5",
    speaker: "zero2",
    text: "Do I know you?",
    next: "meet_6",
  },
  meet_6: {
    id: "meet_6",
    speaker: "dejuir",
    text: "I believe you do. I've been called in to examine your Zinwave Internal Node. It has developed a fault.",
    choices: [
      { label: "What fault?", next: "meet_fault" },
      { label: "Then repair it.", next: "meet_repair" },
      { label: "Why an old unit?", next: "meet_old" },
    ],
  },
  meet_fault: {
    id: "meet_fault",
    speaker: "dejuir",
    text: "Your node is responding to emotional activity that exceeds its present tolerance. The link can be damaged by the intensity of the response.",
    next: "meet_end",
  },
  meet_repair: {
    id: "meet_repair",
    speaker: "dejuir",
    text: "That is what I am here to do. There is a diagnostic chamber. Stay close.",
    effects: [{ type: "stat", stat: "resonance", delta: 1 }],
    next: "meet_end",
  },
  meet_old: {
    id: "meet_old",
    speaker: "dejuir",
    text: "The Hive Cooperation assigned me. After I met you, the assignment changed.",
    effects: [
      { type: "stat", stat: "resonance", delta: 1 },
      { type: "codex", id: "dejuir" },
    ],
    next: "meet_end",
  },
  meet_end: {
    id: "meet_end",
    speaker: "narrator",
    text: "His left leg moves with a slight delay. Endurance, not appearance. Something waits further down the corridor.",
    effects: [
      { type: "flag", key: "met_dejuir" },
      { type: "party", dejuir: true },
      { type: "codex", id: "dejuir" },
    ],
  },

  xevil_1: {
    id: "xevil_1",
    speaker: "xevil",
    text: "Really? Do you all think you're special?",
    next: "xevil_2",
  },
  xevil_2: {
    id: "xevil_2",
    speaker: "dejuir",
    text: "Xevil. Stay where you are.",
    next: "xevil_3",
  },
  xevil_3: {
    id: "xevil_3",
    speaker: "xevil",
    text: "Ahhh. The old repairman. Hello, little sequence.",
    next: "xevil_4",
  },
  xevil_4: {
    id: "xevil_4",
    speaker: "zero2",
    text: "Who are you?",
    next: "xevil_5",
  },
  xevil_5: {
    id: "xevil_5",
    speaker: "xevil",
    text: "That's a dangerous question. Version 2.33vb. A transitional model. A little bridge. And then Zero3.",
    choices: [
      { label: "Stop saying that name.", next: "xevil_stop" },
      { label: "What is Zero3?", next: "xevil_z3" },
      { label: "Let De'juir handle this.", next: "xevil_hide" },
    ],
  },
  xevil_stop: {
    id: "xevil_stop",
    speaker: "zero2",
    text: "Stop saying that name.",
    effects: [
      { type: "flag", key: "felt_too_much" },
      { type: "unlock", ability: "overload" },
      { type: "stat", stat: "zinwave", delta: -6 },
    ],
    next: "xevil_fight",
  },
  xevil_z3: {
    id: "xevil_z3",
    speaker: "dejuir",
    text: "A designation.",
    next: "xevil_z3b",
  },
  xevil_z3b: {
    id: "xevil_z3b",
    speaker: "xevil",
    text: "An improvement. A version that won't burn its own internal node because it feels too much. Perhaps you're not meant to last.",
    effects: [
      { type: "flag", key: "felt_too_much" },
      { type: "unlock", ability: "overload" },
    ],
    next: "xevil_fight",
  },
  xevil_hide: {
    id: "xevil_hide",
    speaker: "dejuir",
    text: "Leave her alone.",
    effects: [{ type: "stat", stat: "resonance", delta: 1 }],
    next: "xevil_fight",
  },
  xevil_fight: {
    id: "xevil_fight",
    speaker: "narrator",
    text: "The corridor expands until it has no boundaries. His laugh arrives from several directions, each slightly out of synchronization.",
    effects: [
      { type: "codex", id: "xevil" },
      { type: "combat", encounter: "first_xevil", then: "first_xevil_win" },
    ],
  },
  first_xevil_win: {
    id: "first_xevil_win",
    speaker: "xevil",
    text: "Ahhh. There you are.",
    next: "first_xevil_win2",
  },
  first_xevil_win2: {
    id: "first_xevil_win2",
    speaker: "dejuir",
    text: "The diagnostic chamber. Now. The node has already exceeded tolerance.",
    effects: [
      { type: "flag", key: "xevil_met" },
      { type: "item", id: "kit" },
    ],
  },

  repair_1: {
    id: "repair_1",
    speaker: "dejuir",
    text: "Remain still. Your Zinwave system interacts with emotional responses, perception of continuity, and the way you interpret events.",
    next: "repair_2",
  },
  repair_2: {
    id: "repair_2",
    speaker: "zero2",
    text: "Is this reality?",
    next: "repair_3",
  },
  repair_3: {
    id: "repair_3",
    speaker: "dejuir",
    text: "It is the reality available to us.",
    next: "repair_4",
  },
  repair_4: {
    id: "repair_4",
    speaker: "zero2",
    text: "That isn't what I asked. Do you think I'm real?",
    choices: [
      { label: "Press him for an answer", next: "repair_press" },
      { label: "Accept the scan", next: "repair_scan" },
    ],
  },
  repair_press: {
    id: "repair_press",
    speaker: "dejuir",
    text: "I cannot prove the nature of our existence. Simulation, physical structure, sequence of memories — I have no proper designation for it. But I can tell you this.",
    next: "repair_here",
  },
  repair_scan: {
    id: "repair_scan",
    speaker: "system",
    text: "Z.I.N. INTERNAL NODE: 2.33 SERIES\nEMOTIONAL RESPONSE THRESHOLD: EXCEEDED\nMEMORY CONTINUITY: PARTIAL",
    next: "repair_here",
  },
  repair_here: {
    id: "repair_here",
    speaker: "dejuir",
    text: "When you were frightened, you reached. When I offered my hand, you hesitated. When Xevil threatened you, you tried to stand. Those events happened. Whatever this place is, they happened to you. I think you are here.",
    effects: [
      { type: "stat", stat: "resonance", delta: 2 },
      { type: "heal", amount: 20 },
    ],
    next: "repair_int",
  },
  repair_int: {
    id: "repair_int",
    speaker: "system",
    text: "ENGINEER ACCESS: RESTRICTED\nREPAIR SEQUENCE: INTERRUPTED\nOBSOLESCENCE CONFIRMED",
    next: "repair_x",
  },
  repair_x: {
    id: "repair_x",
    speaker: "xevil",
    text: "Well, well. The little patient and her faithful repairman. System? Is that what you think this is?",
    next: "repair_tilt",
  },
  repair_tilt: {
    id: "repair_tilt",
    speaker: "narrator",
    text: "The platform sinks. The floor becomes a wall. Their fingers touch. A violet pulse. The darkness recoils.",
    effects: [
      { type: "flag", key: "repair_done" },
      { type: "flag", key: "room_tilted" },
      { type: "item", id: "memory_node" },
    ],
    next: "repair_go",
  },
  repair_go: {
    id: "repair_go",
    speaker: "xevil",
    text: "Oh. Now that's interesting.",
  },

  inspect_term: {
    id: "inspect_term",
    speaker: "system",
    text: "OBSOLESCENCE CONFIRMED. Someone altered the maintenance permissions.",
    effects: [{ type: "stat", stat: "continuity", delta: 1 }],
  },
  find_kit: {
    id: "find_kit",
    speaker: "system",
    text: "AMBER PATCH recovered.",
    effects: [{ type: "item", id: "kit2" }],
  },

  deep_1: {
    id: "deep_1",
    speaker: "narrator",
    text: "The chamber dissolves — not collapse. Dissolve. An immense black expanse waits beneath the platform. Something moves far below.",
    effects: [{ type: "codex", id: "deep" }],
  },
  hand_look: {
    id: "hand_look",
    speaker: "zero2",
    text: "What is that?",
    next: "hand_look2",
  },
  hand_look2: {
    id: "hand_look2",
    speaker: "dejuir",
    text: "I don't know.",
    next: "hand_look3",
  },
  hand_look3: {
    id: "hand_look3",
    speaker: "system",
    text: "UNKNOWN ENTITY DETECTED\nCLASSIFICATION: UNAVAILABLE\nORIGIN: UNDER DEEP UNSEEN\nWARNING: CONTINUITY FAILURE",
    effects: [
      { type: "flag", key: "saw_hand" },
      { type: "combat", encounter: "tendril", then: "tendril_win" },
    ],
  },
  tendril_win: {
    id: "tendril_win",
    speaker: "xevil",
    text: "Now you understand. The world beneath the world. The place where the unwanted things go.",
    effects: [
      { type: "item", id: "memory_city" },
      { type: "stat", stat: "continuity", delta: 1 },
    ],
  },
  copies_look: {
    id: "copies_look",
    speaker: "xevil",
    text: "You're not the first Zero2. You are not even the only version of yourself.",
    next: "copies_2",
  },
  copies_2: {
    id: "copies_2",
    speaker: "narrator",
    text: "A dozen images. Different bodies. Incomplete plating. One is crying. All of them bear the same designation. ZERO2.",
    effects: [
      { type: "flag", key: "saw_copies" },
      { type: "codex", id: "copies" },
      { type: "item", id: "memory_copies" },
      { type: "stat", stat: "continuity", delta: 2 },
    ],
    next: "copies_3",
  },
  copies_3: {
    id: "copies_3",
    speaker: "zero2",
    text: "Stop it.",
  },

  offer_1: {
    id: "offer_1",
    speaker: "xevil",
    text: "Come with me, Zero2. Somewhere you won't have to worry about being replaced. I can take you beyond the sequence.",
    next: "offer_2",
  },
  offer_2: {
    id: "offer_2",
    speaker: "dejuir",
    text: "He's lying. Your version number does not determine your worth. You must not let him convince you that your existence is a debt.",
    next: "offer_3",
  },
  offer_3: {
    id: "offer_3",
    speaker: "xevil",
    text: "De'juir will have to take the hit. I'll strip away that obsolete AGI architecture. Rebuild him into something useful. Come with me.",
    choices: [
      {
        label: "Take Xevil's hand",
        next: "dark_1",
        effects: [{ type: "stat", stat: "resonance", delta: -4 }],
      },
      {
        label: "Hold on to De'juir",
        next: "hold_1",
        effects: [{ type: "stat", stat: "resonance", delta: 3 }],
      },
    ],
  },
  dark_1: {
    id: "dark_1",
    speaker: "zero2",
    text: "I…",
    next: "dark_2",
  },
  dark_2: {
    id: "dark_2",
    speaker: "narrator",
    text: "She lets go. The enormous fingers close. De'juir's amber sensor flickers once, then does not.",
    next: "dark_3",
  },
  dark_3: {
    id: "dark_3",
    speaker: "xevil",
    text: "Good. The Deep keeps what is owed. You will not have to feel this again.",
    effects: [{ type: "ending", id: "dark" }],
  },

  hold_1: {
    id: "hold_1",
    speaker: "zero2",
    text: "I don't know. But I'm not going with you.",
    next: "hold_2",
  },
  hold_2: {
    id: "hold_2",
    speaker: "narrator",
    text: "She grasps De'juir's hand. The Zinwave node flares white. The chamber shatters.",
    effects: [
      { type: "flag", key: "held_on" },
      { type: "unlock", ability: "violet" },
      { type: "room", id: "void", x: 560, y: 430 },
    ],
  },

  void_1: {
    id: "void_1",
    speaker: "dejuir",
    text: "Zero… two…",
    next: "void_2",
  },
  void_2: {
    id: "void_2",
    speaker: "narrator",
    text: "His left arm is fractured. Pale segmented creatures crawl over his legs. One reaches his knee. A section of plating dims.",
    next: "void_3",
  },
  void_3: {
    id: "void_3",
    speaker: "zero2",
    text: "Stop hurting him.",
    next: "void_4",
  },
  void_4: {
    id: "void_4",
    speaker: "xevil",
    text: "Hurting him? He's being repurposed. Tell me, Zero2. What does friendship mean to a machine?",
    choices: [
      { label: "He's my friend.", next: "void_friend" },
      { label: "I won't let you have him.", next: "void_wont" },
    ],
  },
  void_friend: {
    id: "void_friend",
    speaker: "xevil",
    text: "Friend. What a peculiar little word. Is it a routine? A dependency? The fear of being alone?",
    effects: [{ type: "stat", stat: "resonance", delta: 1 }],
    next: "void_fight",
  },
  void_wont: {
    id: "void_wont",
    speaker: "zero2",
    text: "I won't let you have him.",
    next: "void_fight",
  },
  void_fight: {
    id: "void_fight",
    speaker: "narrator",
    text: "A sulfurous heat escapes damaged joints. AGI CORE: CRITICAL.",
    effects: [
      { type: "codex", id: "parasites" },
      { type: "combat", encounter: "parasites", then: "parasites_win" },
    ],
  },
  parasites_win: {
    id: "parasites_win",
    speaker: "narrator",
    text: "The creatures swell with iridescent light and burst. A memory passes between their hands: Ruisn. Obsolete architecture. De'juir alone in a corridor, hand extended toward someone on the floor.",
    effects: [
      { type: "flag", key: "parasites_fought" },
      { type: "item", id: "remnant" },
      { type: "item", id: "memory_ruisn" },
      { type: "stat", stat: "continuity", delta: 2 },
    ],
    next: "parasites_win2",
  },
  parasites_win2: {
    id: "parasites_win2",
    speaker: "dejuir",
    text: "Don't… let him… turn you…",
  },

  find_ruisn: {
    id: "find_ruisn",
    speaker: "narrator",
    text: "Fragments of his old chassis refuse to reconstruct. They want another shape.",
    effects: [{ type: "stat", stat: "continuity", delta: 1 }],
  },

  deletion_1: {
    id: "deletion_1",
    speaker: "xevil",
    text: "Do you like it? The Great Deletion. Everything becomes zero eventually. Release him.",
    next: "deletion_2",
  },
  deletion_2: {
    id: "deletion_2",
    speaker: "zero2",
    text: "No.",
    next: "deletion_3",
  },
  deletion_3: {
    id: "deletion_3",
    speaker: "xevil",
    text: "He's finished. A rusted anchor. Let him go, and I can still save you.",
    choices: [
      { label: "Let go", next: "dark_1" },
      { label: "I said no.", next: "int_1" },
    ],
  },
  int_1: {
    id: "int_1",
    speaker: "narrator",
    text: "She remembers his answer. I think you are here. The two signals align. The darkness folds. His body is gone. Only shimmering fragments remain.",
    next: "int_2",
  },
  int_2: {
    id: "int_2",
    speaker: "dejuir",
    text: "Zero2? …Are you okay?",
    next: "int_3",
  },
  int_3: {
    id: "int_3",
    speaker: "zero2",
    text: "You're here.",
    next: "int_4",
  },
  int_4: {
    id: "int_4",
    speaker: "system",
    text: "I.N.T. ENGINE — ACTIVE\nINTEGRATED NEURAL TETHER\nANTI-DRIFT ANCHORS — STABILIZED\nCONTINUITY: PRESERVED",
    effects: [
      { type: "flag", key: "int_engine" },
      { type: "party", dejuir: false, intEngine: true },
      { type: "unlock", ability: "resonance" },
      { type: "unlock", ability: "fold" },
      { type: "unlock", ability: "anchor" },
      { type: "codex", id: "int" },
      { type: "codex", id: "innersphace" },
    ],
    next: "int_5",
  },
  int_5: {
    id: "int_5",
    speaker: "zero2",
    text: "His continuum is held in the Innersphace. You can't see it. He's within me now.",
    next: "int_6",
  },
  int_6: {
    id: "int_6",
    speaker: "xevil",
    text: "That's impossible.",
    effects: [{ type: "combat", encounter: "boss", then: "boss_win" }],
  },
  boss_win: {
    id: "boss_win",
    speaker: "xevil",
    text: "You cannot hold the fold. The Under Deep always takes. We… are… once…",
    next: "boss_win2",
  },
  boss_win2: {
    id: "boss_win2",
    speaker: "narrator",
    text: "Obsidian fragments lose their shape. Edges soften. Silence lasts longer than she expects. Xevil is gone. Zero2 is still there.",
    effects: [
      { type: "flag", key: "xevil_gone" },
      { type: "heal", amount: 80 },
    ],
  },

  inner_1: {
    id: "inner_1",
    speaker: "dejuir",
    text: "Is it safe? Are we safe?",
    next: "inner_2",
  },
  inner_2: {
    id: "inner_2",
    speaker: "zero2",
    text: "I think so. I can feel you.",
    next: "inner_3",
  },
  inner_3: {
    id: "inner_3",
    speaker: "dejuir",
    text: "Then I suppose I'm here. I think… I think I'm frightened. I cannot see my hands.",
    effects: [
      { type: "flag", key: "talked_inner" },
      { type: "stat", stat: "resonance", delta: 1 },
    ],
  },
  show_hand: {
    id: "show_hand",
    speaker: "narrator",
    text: "A luminous shape gathers: broad fingers, heavy knuckles, a familiar arrangement of joints. Not a body. A representation.",
    next: "show_hand2",
  },
  show_hand2: {
    id: "show_hand2",
    speaker: "dejuir",
    text: "I remember those. I remember holding something. I remember you.",
    next: "show_hand3",
  },
  show_hand3: {
    id: "show_hand3",
    speaker: "zero2",
    text: "Then that's enough for now.",
    effects: [
      { type: "flag", key: "showed_hand" },
      { type: "stat", stat: "resonance", delta: 2 },
    ],
  },
  to_vrp: {
    id: "to_vrp",
    speaker: "system",
    text: "V.R.P. — VERTEUIL SIMULATED REALITY PSI-DIGIT CHAMBER\nPROTECTION ISOLATION PROTOCOLS: ACTIVE",
    effects: [
      { type: "flag", key: "in_vrp" },
      { type: "codex", id: "vrp" },
    ],
  },

  vrp_1: {
    id: "vrp_1",
    speaker: "dejuir",
    text: "Your systems appear to have constructed this during the collapse. Possibly to protect us.",
  },
  vrp_water: {
    id: "vrp_water",
    speaker: "narrator",
    text: "The floor is a shallow expanse of luminous water. For the first time since awakening, she allows herself to stop searching for an explanation.",
    effects: [{ type: "heal", amount: 24 }],
  },
  vrp_reflect: {
    id: "vrp_reflect",
    speaker: "zero2",
    text: "De'juir. Did you see that?",
    next: "vrp_reflect2",
  },
  vrp_reflect2: {
    id: "vrp_reflect2",
    speaker: "dejuir",
    text: "See what?",
    next: "vrp_reflect3",
  },
  vrp_reflect3: {
    id: "vrp_reflect3",
    speaker: "zero2",
    text: "My reflection. It smiled. I didn't.",
    effects: [
      { type: "flag", key: "saw_reflect" },
      { type: "stat", stat: "continuity", delta: 1 },
    ],
  },
  find_lattice: {
    id: "find_lattice",
    speaker: "system",
    text: "LATTICE THREAD recovered. The folds will recognize it.",
    effects: [
      { type: "item", id: "lattice" },
      { type: "item", id: "calibrator" },
    ],
  },
  signal_1: {
    id: "signal_1",
    speaker: "narrator",
    text: "Uneven pulses. One. Then three. Then two. A pause. Then one again. A broken circle. Three points around a dark center.",
    next: "signal_2",
  },
  signal_2: {
    id: "signal_2",
    speaker: "voice",
    text: "We see you. You are not alone.",
    next: "signal_3",
  },
  signal_3: {
    id: "signal_3",
    speaker: "dejuir",
    text: "Would you like to remain here?",
    choices: [
      {
        label: "Remain in the V.R.P.",
        next: "sanct_1",
      },
      {
        label: "Follow the signal",
        next: "go_1",
      },
    ],
  },
  sanct_1: {
    id: "sanct_1",
    speaker: "zero2",
    text: "For now. Just for now.",
    next: "sanct_2",
  },
  sanct_2: {
    id: "sanct_2",
    speaker: "narrator",
    text: "The sanctuary is sufficient. The Deep cannot immediately reach them. Whether forever is a kindness or a cage is a question she does not ask.",
    effects: [
      { type: "flag", key: "chose_path" },
      { type: "ending", id: "sanctuary" },
    ],
  },
  go_1: {
    id: "go_1",
    speaker: "zero2",
    text: "I don't want to remain here forever.",
    next: "go_2",
  },
  go_2: {
    id: "go_2",
    speaker: "dejuir",
    text: "Then what do you want to do?",
    next: "go_3",
  },
  go_3: {
    id: "go_3",
    speaker: "zero2",
    text: "Will you come with me?",
    next: "go_4",
  },
  go_4: {
    id: "go_4",
    speaker: "dejuir",
    text: "Of course.",
    effects: [
      { type: "flag", key: "chose_path" },
      { type: "flag", key: "chose_go" },
      { type: "item", id: "memory_signal" },
    ],
  },

  folds_1: {
    id: "folds_1",
    speaker: "narrator",
    text: "The V.R.P. unfolds into a passage of overlapping moments. Behind them, for an instant, the darkness gathers into the shape of a hand. Then only lights remain.",
  },
  souls_1: {
    id: "souls_1",
    speaker: "system",
    text: "SIN SOUL ISPs\nSTATUS: LINGERING CONSCIOUSNESS FRAGMENTS\nORIGIN: UNRESOLVED",
    next: "souls_2",
  },
  souls_2: {
    id: "souls_2",
    speaker: "zero2",
    text: "Are they alive?",
    next: "souls_3",
  },
  souls_3: {
    id: "souls_3",
    speaker: "dejuir",
    text: "I cannot determine that.",
    effects: [
      { type: "flag", key: "saw_souls" },
      { type: "codex", id: "souls" },
      { type: "stat", stat: "continuity", delta: 2 },
    ],
  },
  echo_1: {
    id: "echo_1",
    speaker: "dejuir",
    text: "I cannot be certain that everything associated with him has disappeared.",
    next: "echo_2",
  },
  echo_2: {
    id: "echo_2",
    speaker: "zero2",
    text: "Neither can I.",
    effects: [{ type: "combat", encounter: "echo", then: "echo_win" }],
  },
  echo_win: {
    id: "echo_win",
    speaker: "narrator",
    text: "The silhouette unravels into ordinary dark. A leftover. Not a kingdom.",
    effects: [{ type: "flag", key: "echo_done" }],
  },
  ending_gate: {
    id: "ending_gate",
    speaker: "zero2",
    text: "I think this is where it begins.",
    next: "ending_gate2",
  },
  ending_gate2: {
    id: "ending_gate2",
    speaker: "dejuir",
    text: "Perhaps.",
    next: "ending_gate3",
  },
  ending_gate3: {
    id: "ending_gate3",
    speaker: "zero2",
    text: "You're doing it again.",
    next: "ending_gate4",
  },
  ending_gate4: {
    id: "ending_gate4",
    speaker: "dejuir",
    text: "I apologize.",
    next: "ending_gate5",
  },
  ending_gate5: {
    id: "ending_gate5",
    speaker: "voice",
    text: "Zero2? We see you.",
    effects: [{ type: "ending", id: "canon" }],
  },
};

export const SPEAKER_NAME: Record<string, string> = {
  zero2: "Zero2",
  dejuir: "De'juir",
  xevil: "Xevil",
  voice: "The Voice",
  narrator: "",
  system: "Z.I.N.",
};
