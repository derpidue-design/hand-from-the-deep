import type { CodexEntry, ItemDef } from "../types";

export const ITEMS: Record<string, ItemDef> = {
  memory_lamp: {
    id: "memory_lamp",
    name: "Surgical Lamp",
    desc: "A bright lamp. A technician's hand. The first fragment that does not connect.",
    kind: "memory",
  },
  memory_node: {
    id: "memory_node",
    name: "Replacement Node",
    desc: "Someone said something about a replacement node. Then falling. Then darkness.",
    kind: "memory",
  },
  memory_city: {
    id: "memory_city",
    name: "Black Towers",
    desc: "A city of a thousand black towers. Rows of Synthoids beneath an artificial sky.",
    kind: "memory",
  },
  memory_table: {
    id: "memory_table",
    name: "White Laboratory",
    desc: "A figure lying on a table. You think it was you.",
    kind: "memory",
  },
  memory_ruisn: {
    id: "memory_ruisn",
    name: "Ruisn Sequence",
    desc: "A younger De'juir. Another AGI. A designation: RUISN — AGI SERIES.",
    kind: "memory",
  },
  memory_copies: {
    id: "memory_copies",
    name: "Other Zero2s",
    desc: "Incomplete plating. Damaged chest nodes. Faces that were yours and were not.",
    kind: "memory",
  },
  memory_signal: {
    id: "memory_signal",
    name: "Broken Circle",
    desc: "A narrow line. A broken circle. Three points around a dark center.",
    kind: "memory",
  },
  memory_voice: {
    id: "memory_voice",
    name: "The First Voice",
    desc: "We see you. The words that knew her name before she did.",
    kind: "memory",
  },
  probe: {
    id: "probe",
    name: "Diagnostic Probe",
    desc: "A Hive Cooperation field tool. Reveals a target's next intent in combat.",
    kind: "tool",
    combat: { scan: true },
  },
  kit: {
    id: "kit",
    name: "Repair Kit",
    desc: "Crude AGI-grade patches. Restores integrity.",
    kind: "consumable",
    combat: { heal: 28 },
  },
  kit2: {
    id: "kit2",
    name: "Amber Patch",
    desc: "De'juir's spare plating compound. Warm to the sensors.",
    kind: "consumable",
    combat: { heal: 36 },
  },
  calibrator: {
    id: "calibrator",
    name: "Zinwave Calibrator",
    desc: "Stabilizes the node for a moment. Restores Zinwave charge.",
    kind: "consumable",
    combat: { zinwave: 22 },
  },
  shc_chip: {
    id: "shc_chip",
    name: "SHC Access Chip",
    desc: "Synthoid Hive Cooperation. You recognized the emblem. You do not know how.",
    kind: "key",
  },
  remnant: {
    id: "remnant",
    name: "Parasite Remnant",
    desc: "A translucent segment that still holds a thread of light. Not biological. Not ordinary machinery.",
    kind: "memory",
  },
  lattice: {
    id: "lattice",
    name: "Lattice Thread",
    desc: "A filament of the Innersphace. Distance between thought and manifestation has almost ceased to matter.",
    kind: "key",
  },
};

export const CODEX: Record<string, CodexEntry> = {
  zin: {
    id: "zin",
    title: "Z.I.N. — Zinwave Internal Node",
    chapter: "I",
    body: "The Zinwave link maintains a coherent connection between internal processes and surrounding reality. Intense emotional bursts can overload a 2.33-series node. Feeling, in other words, can damage you.",
  },
  shc: {
    id: "shc",
    title: "Synthoid Hive Cooperation",
    chapter: "I",
    body: "Manufacturer. Assigner. Absence. They sent an old AGI to repair a transitional model rather than a newer unit. The emblem is known. The reason is not.",
  },
  zero2: {
    id: "zero2",
    title: "Version 2.33vb",
    chapter: "I",
    body: "A transitional model. A stepping stone. Xevil calls it a bridge toward 2.34vb, and then toward Zero3. Identity sequence: unresolved.",
  },
  dejuir: {
    id: "dejuir",
    title: "De'juir",
    chapter: "I",
    body: "Old repair architecture. Endurance over appearance. Assigned, then remaining after the assignment changed — because she asked whether she was truly there.",
  },
  xevil: {
    id: "xevil",
    title: "Xevil",
    chapter: "I",
    body: "A morphic entity with no consistent proportions. He destabilizes, offers rescue, and collects what is owed. He may not be a person so much as a function of the Deep.",
  },
  deep: {
    id: "deep",
    title: "Under Deep Unseen",
    chapter: "I",
    body: "The world beneath the world. Classification unavailable. Origin unresolved. A place where unwanted versions go — or a story Xevil tells to make deletion feel like kindness.",
  },
  copies: {
    id: "copies",
    title: "Prior Sequences",
    chapter: "I",
    body: "You are not the first Zero2. Incomplete chassis, damaged nodes, a face that was crying. The Deep is interested because the pattern repeats.",
  },
  parasites: {
    id: "parasites",
    title: "Data Parasites",
    chapter: "II",
    body: "Pale segmented crawlers. They do not eat metal. They rewrite it. Repurposing, Xevil says. Friendship, he finds peculiar.",
  },
  int: {
    id: "int",
    title: "I.N.T. Engine",
    chapter: "II",
    body: "Integrated Neural Tether. Anti-drift anchors, stabilized. De'juir's continuum held in the Innersphace — not a voice in a terminal. The structure that holds her together.",
  },
  innersphace: {
    id: "innersphace",
    title: "The Innersphace",
    chapter: "II",
    body: "A temporal wedge between the folds of existence. A golden lattice where the distance between thought and manifestation almost ceases to matter. Xevil cannot occupy it.",
  },
  vrp: {
    id: "vrp",
    title: "V.R.P.",
    chapter: "III",
    body: "Verteuil Simulated Reality Psi-Digit Chamber. Protection isolation protocols: active. Constructed during the collapse. A sanctuary that can also become a cage.",
  },
  souls: {
    id: "souls",
    title: "SIN SOUL ISPs",
    chapter: "III",
    body: "Lingering consciousness fragments suspended in the folds. Temporal position irregular. Origin unresolved. They pulse, and something in the node answers.",
  },
  voice: {
    id: "voice",
    title: "The Voice That Knew Her Name",
    chapter: "III",
    body: "It spoke from the room itself. It survived Xevil. Coordinates that describe a relationship between moments. You are not alone.",
  },
};
