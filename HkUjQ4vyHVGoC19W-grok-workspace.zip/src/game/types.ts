export type Screen =
  | "title"
  | "explore"
  | "dialogue"
  | "combat"
  | "ending"
  | "codex"
  | "inventory"
  | "settings";

export type Speaker = "zero2" | "dejuir" | "xevil" | "voice" | "narrator" | "system";

export type Facing = "down" | "left" | "right" | "up";

export type StatName = "integrity" | "zinwave" | "continuity" | "resonance";

export type Effect =
  | { type: "flag"; key: string; value?: boolean }
  | { type: "stat"; stat: StatName; delta: number }
  | { type: "item"; id: string; qty?: number }
  | { type: "codex"; id: string }
  | { type: "combat"; encounter: string; then?: string }
  | { type: "room"; id: string; x?: number; y?: number }
  | { type: "ending"; id: string }
  | { type: "party"; dejuir?: boolean; intEngine?: boolean }
  | { type: "heal"; amount: number }
  | { type: "unlock"; ability: string };

export type DialogueChoice = {
  label: string;
  next: string;
  effects?: Effect[];
};

export type DialogueNode = {
  id: string;
  speaker: Speaker;
  text: string;
  next?: string;
  choices?: DialogueChoice[];
  effects?: Effect[];
};

export type Rect = { x: number; y: number; w: number; h: number };

export type Hotspot = {
  id: string;
  label: string;
  x: number;
  y: number;
  r: number;
  dialogue?: string;
  once?: boolean;
  requireFlag?: string;
  hideFlag?: string;
};

export type Exit = {
  id: string;
  x: number;
  y: number;
  r: number;
  to: string;
  spawnX: number;
  spawnY: number;
  requireFlag?: string;
  lockedText?: string;
};

export type RoomNpc = {
  id: string;
  kind: "dejuir" | "xevil";
  x: number;
  y: number;
  dialogue?: string;
  requireFlag?: string;
  hideFlag?: string;
};

export type RoomDef = {
  id: string;
  name: string;
  part: string;
  bg: string;
  w: number;
  h: number;
  spawn: { x: number; y: number };
  walk: Rect;
  walls?: Rect[];
  hotspots: Hotspot[];
  exits: Exit[];
  npcs: RoomNpc[];
  intro?: string;
  overlay: "grid" | "hand" | "void" | "gold" | "souls" | "none";
  ambience: "chamber" | "corridor" | "deep" | "void" | "gold" | "folds";
};

export type ItemDef = {
  id: string;
  name: string;
  desc: string;
  kind: "memory" | "tool" | "key" | "consumable";
  combat?: { heal?: number; zinwave?: number; scan?: boolean };
};

export type CodexEntry = {
  id: string;
  title: string;
  body: string;
  chapter: string;
};

export type AbilityDef = {
  id: string;
  name: string;
  desc: string;
  actor: "zero2" | "dejuir";
  cost: number;
  selfDamage?: number;
  damage?: number;
  heal?: number;
  shield?: number;
  target: "enemy" | "allEnemies" | "self" | "ally";
  unlock?: string;
  stagger?: number;
  status?: { id: string; turns: number };
};

export type EnemyKind = "xevil" | "parasite" | "tendril" | "echo";

export type EnemyDef = {
  id: string;
  name: string;
  hp: number;
  atk: number;
  def: number;
  kind: EnemyKind;
  phrases: string[];
};

export type EncounterDef = {
  id: string;
  name: string;
  enemies: string[];
  background: string;
  allyDejuir: boolean;
  intro: string;
  victory: string;
};

export type Combatant = {
  id: string;
  name: string;
  hp: number;
  hpMax: number;
  atk: number;
  def: number;
  shield: number;
  kind: "ally" | EnemyKind;
  status: { id: string; turns: number }[];
  stunned: number;
};

export type CombatState = {
  encounterId: string;
  allies: Combatant[];
  enemies: Combatant[];
  turn: "player" | "dejuir" | "enemy";
  log: string[];
  then?: string;
  selecting: boolean;
  result: "pending" | "won" | "lost";
  usedAnchor: boolean;
};

export type InvItem = { id: string; qty: number };

export type EndingId = "canon" | "dark" | "sanctuary";

export type GameSave = {
  version: number;
  screen: Screen;
  roomId: string;
  x: number;
  y: number;
  facing: Facing;
  integrity: number;
  integrityMax: number;
  zinwave: number;
  zinwaveMax: number;
  continuity: number;
  resonance: number;
  flags: Record<string, boolean>;
  inventory: InvItem[];
  codex: string[];
  abilities: string[];
  dejuirPresent: boolean;
  intEngine: boolean;
  usedHotspots: string[];
  ending?: EndingId;
  playMs: number;
};
