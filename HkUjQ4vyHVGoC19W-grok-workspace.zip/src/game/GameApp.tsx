import { useEffect } from "react";
import { ExploreCanvas } from "./canvas/ExploreCanvas";
import { CombatScreen } from "./ui/CombatScreen";
import { DialogueBox } from "./ui/DialogueBox";
import { EndingScreen } from "./ui/EndingScreen";
import { HUD } from "./ui/HUD";
import { PauseMenu } from "./ui/PauseMenu";
import { TitleScreen } from "./ui/TitleScreen";
import { TouchControls } from "./ui/TouchControls";
import { useGame } from "./store";
import { resumeAudio, setAmbience, setVolumes, unlockAudio } from "./systems/audio";
import { ROOMS } from "./content/rooms";

export function GameApp() {
  const screen = useGame((s) => s.screen);
  const started = useGame((s) => s.started);
  const roomId = useGame((s) => s.roomId);
  const combat = useGame((s) => s.combat);
  const dialogueId = useGame((s) => s.dialogueId);
  const toast = useGame((s) => s.toast);
  const clearToast = useGame((s) => s.clearToast);
  const addPlayMs = useGame((s) => s.addPlayMs);
  const persist = useGame((s) => s.persist);
  const music = useGame((s) => s.music);
  const sfx = useGame((s) => s.sfx);

  useEffect(() => {
    const onFirst = () => unlockAudio();
    window.addEventListener("pointerdown", onFirst, { once: true });
    window.addEventListener("keydown", onFirst, { once: true });
    const vis = () => {
      if (document.hidden) persist();
      else resumeAudio();
    };
    document.addEventListener("visibilitychange", vis);
    const t = window.setInterval(() => addPlayMs(1000), 1000);
    return () => {
      window.removeEventListener("pointerdown", onFirst);
      window.removeEventListener("keydown", onFirst);
      document.removeEventListener("visibilitychange", vis);
      window.clearInterval(t);
    };
  }, [addPlayMs, persist]);

  useEffect(() => {
    setVolumes(0.7, music, sfx);
  }, [music, sfx]);

  useEffect(() => {
    if (screen === "title") setAmbience("title");
    else if (screen === "ending") setAmbience("gold");
    else if (combat) setAmbience("deep");
    else setAmbience(ROOMS[roomId]?.ambience ?? "chamber");
  }, [screen, roomId, combat]);

  useEffect(() => {
    if (!toast) return;
    const t = window.setTimeout(clearToast, 2800);
    return () => window.clearTimeout(t);
  }, [toast, clearToast]);

  if (screen === "ending") {
    return <EndingScreen />;
  }

  if (screen === "title" || !started) {
    return (
      <div className="relative min-h-dvh bg-void">
        {screen === "title" || !started ? <TitleScreen /> : null}
        <PauseMenu />
      </div>
    );
  }

  return (
    <div className="relative h-dvh overflow-hidden bg-void text-frost">
      <ExploreCanvas />
      <HUD />
      <TouchControls />
      {dialogueId ? <DialogueBox /> : null}
      {combat ? <CombatScreen /> : null}
      <PauseMenu />
      {toast ? (
        <div className="pointer-events-none absolute top-24 left-1/2 z-40 -translate-x-1/2 rounded-md border border-line bg-void/90 px-3 py-2 font-mono text-[11px] tracking-wide text-signal">
          {toast}
        </div>
      ) : null}
    </div>
  );
}
