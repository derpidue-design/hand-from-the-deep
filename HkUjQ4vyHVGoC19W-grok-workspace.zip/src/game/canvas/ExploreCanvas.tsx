import { useEffect, useRef } from "react";
import { ROOMS } from "../content/rooms";
import { bindInput, pollActions, setInjectedKeys, touch } from "../systems/input";
import { useGame } from "../store";
import type { Facing } from "../types";

const WORLD_W = 1280;
const WORLD_H = 720;
const SPEED = 210;

const images = new Map<string, HTMLImageElement>();

function loadImg(src: string): HTMLImageElement {
  const hit = images.get(src);
  if (hit) return hit;
  const img = new Image();
  img.crossOrigin = "anonymous";
  img.src = src;
  images.set(src, img);
  return img;
}

function circleHit(ax: number, ay: number, bx: number, by: number, r: number): boolean {
  const dx = ax - bx;
  const dy = ay - by;
  return dx * dx + dy * dy <= r * r;
}

function clampToWalk(x: number, y: number, walk: { x: number; y: number; w: number; h: number }, rad: number) {
  return {
    x: Math.max(walk.x + rad, Math.min(walk.x + walk.w - rad, x)),
    y: Math.max(walk.y + rad, Math.min(walk.y + walk.h - rad, y)),
  };
}

function facingOf(dx: number, dy: number, prev: Facing): Facing {
  if (Math.abs(dx) < 0.01 && Math.abs(dy) < 0.01) return prev;
  if (Math.abs(dx) > Math.abs(dy)) return dx < 0 ? "left" : "right";
  return dy < 0 ? "up" : "down";
}

function yawOf(facing: Facing): number {
  if (facing === "up") return 0;
  if (facing === "left") return Math.PI / 2;
  if (facing === "down") return Math.PI;
  return -Math.PI / 2;
}

function drawSheet(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  x: number,
  y: number,
  facing: Facing,
  frame: number,
  height: number,
) {
  if (!img.complete || img.naturalWidth < 8) return;
  const cols = 4;
  const rows = 4;
  const cw = img.naturalWidth / cols;
  const ch = img.naturalHeight / rows;
  const row = facing === "down" ? 0 : facing === "left" ? 1 : facing === "right" ? 2 : 3;
  const col = frame % 4;
  const w = height * (cw / ch);
  ctx.drawImage(img, col * cw, row * ch, cw, ch, x - w / 2, y - height, w, height);
}

function drawXevil(ctx: CanvasRenderingContext2D, x: number, y: number, t: number) {
  ctx.save();
  ctx.translate(x, y - 40);
  const wobble = Math.sin(t * 1.7) * 6;
  ctx.rotate(Math.sin(t * 0.8) * 0.08);
  const g = ctx.createRadialGradient(0, 0, 4, 0, 0, 48);
  g.addColorStop(0, "rgba(20,10,24,0.2)");
  g.addColorStop(0.5, "rgba(8,8,12,0.92)");
  g.addColorStop(1, "rgba(8,8,12,0)");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.ellipse(wobble * 0.2, 0, 22 + Math.sin(t * 2) * 4, 38 + Math.cos(t * 1.4) * 3, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#050508";
  ctx.beginPath();
  ctx.arc(-6, -10, 3.2, 0, Math.PI * 2);
  ctx.arc(7 + wobble * 0.1, -8, 2.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

type Prompt = { kind: "hotspot" | "npc" | "exit"; id: string; label: string; x: number; y: number };

export function ExploreCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pos = useRef({ x: useGame.getState().x, y: useGame.getState().y, facing: useGame.getState().facing, speed: 0 });
  const promptRef = useRef<Prompt | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const unbind = bindInput(window);
    let raf = 0;
    let last = performance.now();
    let animT = 0;
    let frame = 0;

    loadImg("/game/sprites/zero2.png");
    loadImg("/game/sprites/dejuir.png");
    for (const r of Object.values(ROOMS)) loadImg(r.bg);

    const probe = {
      getYaw: () => yawOf(pos.current.facing),
      getSpeed: () => pos.current.speed,
      setKeys: (codes: string[]) => setInjectedKeys(codes),
      getPos: () => ({ x: pos.current.x, y: pos.current.y }),
    };
    window.__controlsTest = probe;

    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      const st = useGame.getState();
      const room = ROOMS[st.roomId];
      if (!room) return;

      const parent = canvas.parentElement;
      const cssW = parent?.clientWidth ?? 1280;
      const cssH = parent?.clientHeight ?? 720;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      if (canvas.width !== Math.floor(cssW * dpr) || canvas.height !== Math.floor(cssH * dpr)) {
        canvas.width = Math.floor(cssW * dpr);
        canvas.height = Math.floor(cssH * dpr);
        canvas.style.width = `${cssW}px`;
        canvas.style.height = `${cssH}px`;
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, cssW, cssH);

      const scale = Math.min(cssW / WORLD_W, cssH / WORLD_H);
      const ox = (cssW - WORLD_W * scale) / 2;
      const oy = (cssH - WORLD_H * scale) / 2;

      const blocked = Boolean(st.dialogueId || st.paused || st.combat || st.screen !== "explore" || st.ending);
      const actions = pollActions();
      if (!blocked) {
        const nx = pos.current.x + actions.moveX * SPEED * dt;
        const ny = pos.current.y + actions.moveY * SPEED * dt;
        const c = clampToWalk(nx, ny, room.walk, 16);
        pos.current.facing = facingOf(actions.moveX, actions.moveY, pos.current.facing);
        pos.current.speed = Math.hypot(c.x - pos.current.x, c.y - pos.current.y) / Math.max(dt, 0.0001);
        pos.current.x = c.x;
        pos.current.y = c.y;
        if (pos.current.speed > 8) {
          animT += dt;
          frame = Math.floor(animT * 8) % 4;
        } else {
          frame = 0;
          pos.current.speed = 0;
        }
      } else {
        pos.current.speed = 0;
      }

      let prompt: Prompt | null = null;
      if (!blocked) {
        for (const npc of room.npcs) {
          if (npc.requireFlag && !st.flags[npc.requireFlag]) continue;
          if (npc.hideFlag && st.flags[npc.hideFlag]) continue;
          if (circleHit(pos.current.x, pos.current.y, npc.x, npc.y, 54)) {
            prompt = {
              kind: "npc",
              id: npc.id,
              label: npc.kind === "dejuir" ? "Speak with De'juir" : "The obsidian figure",
              x: npc.x,
              y: npc.y,
            };
          }
        }
        for (const hs of room.hotspots) {
          if (hs.requireFlag && !st.flags[hs.requireFlag]) continue;
          if (hs.hideFlag && st.flags[hs.hideFlag]) continue;
          if (hs.once && st.usedHotspots.includes(hs.id)) continue;
          if (circleHit(pos.current.x, pos.current.y, hs.x, hs.y, hs.r + 10)) {
            prompt = { kind: "hotspot", id: hs.id, label: hs.label, x: hs.x, y: hs.y };
          }
        }
        for (const ex of room.exits) {
          if (circleHit(pos.current.x, pos.current.y, ex.x, ex.y, ex.r + 8)) {
            const locked = Boolean(ex.requireFlag && !st.flags[ex.requireFlag]);
            prompt = {
              kind: "exit",
              id: ex.id,
              label: locked ? ex.lockedText ?? "Closed" : "Proceed",
              x: ex.x,
              y: ex.y,
            };
          }
        }
      }
      promptRef.current = prompt;

      if (!blocked && actions.interactPressed && prompt) {
        st.interact(prompt.kind, prompt.id);
      }
      if (!blocked && actions.pausePressed) st.setPaused(true);

      ctx.save();
      ctx.translate(ox, oy);
      ctx.scale(scale, scale);
      ctx.fillStyle = "#07090d";
      ctx.fillRect(0, 0, WORLD_W, WORLD_H);
      const bg = loadImg(room.bg);
      if (bg.complete && bg.naturalWidth) {
        ctx.drawImage(bg, 0, 0, WORLD_W, WORLD_H);
      }

      const t = now / 1000;
      if (room.overlay === "grid") {
        ctx.strokeStyle = "rgba(126,200,227,0.18)";
        ctx.lineWidth = 1;
        const pulse = 0.5 + Math.sin(t * 1.4) * 0.5;
        ctx.globalAlpha = 0.25 + pulse * 0.2;
        ctx.beginPath();
        ctx.arc(pos.current.x, pos.current.y, 70 + Math.sin(t) * 6, 0, Math.PI * 2);
        ctx.stroke();
        ctx.globalAlpha = 1;
      }
      if (room.overlay === "hand" || room.overlay === "void") {
        ctx.globalAlpha = 0.35;
        ctx.fillStyle = "#07090d";
        ctx.beginPath();
        ctx.ellipse(640, 640, 420, 90, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1;
      }
      if (room.overlay === "gold") {
        ctx.fillStyle = "rgba(212,180,106,0.05)";
        ctx.fillRect(0, 0, WORLD_W, WORLD_H);
      }
      if (room.overlay === "souls") {
        for (let i = 0; i < 18; i++) {
          const sx = 180 + ((i * 137) % 900);
          const sy = 260 + ((i * 89) % 280);
          const a = 0.25 + Math.sin(t * 1.2 + i) * 0.2;
          ctx.fillStyle = `rgba(232,238,244,${a})`;
          ctx.beginPath();
          ctx.arc(sx, sy, 2.4 + (i % 3), 0, Math.PI * 2);
          ctx.fill();
        }
      }

      for (const hs of room.hotspots) {
        if (hs.requireFlag && !st.flags[hs.requireFlag]) continue;
        if (hs.hideFlag && st.flags[hs.hideFlag]) continue;
        if (hs.once && st.usedHotspots.includes(hs.id)) continue;
        ctx.beginPath();
        ctx.strokeStyle = "rgba(126,200,227,0.45)";
        ctx.lineWidth = 1.5;
        ctx.arc(hs.x, hs.y - 8, 10 + Math.sin(t * 3) * 1.5, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = "rgba(126,200,227,0.8)";
        ctx.beginPath();
        ctx.arc(hs.x, hs.y - 8, 2.5, 0, Math.PI * 2);
        ctx.fill();
      }
      for (const ex of room.exits) {
        const open = !ex.requireFlag || st.flags[ex.requireFlag];
        ctx.strokeStyle = open ? "rgba(232,238,244,0.55)" : "rgba(139,151,168,0.3)";
        ctx.lineWidth = 1.5;
        ctx.strokeRect(ex.x - 16, ex.y - 22, 32, 36);
      }

      const actors: { z: number; draw: () => void }[] = [];
      for (const npc of room.npcs) {
        if (npc.requireFlag && !st.flags[npc.requireFlag]) continue;
        if (npc.hideFlag && st.flags[npc.hideFlag]) continue;
        actors.push({
          z: npc.y,
          draw: () => {
            if (npc.kind === "dejuir") {
              drawSheet(ctx, loadImg("/game/sprites/dejuir.png"), npc.x, npc.y, "down", 0, 78);
            } else {
              drawXevil(ctx, npc.x, npc.y, t);
            }
          },
        });
      }
      actors.push({
        z: pos.current.y,
        draw: () => {
          drawSheet(
            ctx,
            loadImg("/game/sprites/zero2.png"),
            pos.current.x,
            pos.current.y,
            pos.current.facing,
            frame,
            74,
          );
        },
      });
      actors.sort((a, b) => a.z - b.z);
      for (const a of actors) a.draw();

      if (prompt) {
        ctx.font = "500 16px Outfit, sans-serif";
        const label = prompt.label;
        const tw = ctx.measureText(label).width;
        const px = prompt.x;
        const py = prompt.y - 96;
        ctx.fillStyle = "rgba(7,9,13,0.82)";
        ctx.beginPath();
        ctx.roundRect(px - tw / 2 - 14, py - 16, tw + 28, 30, 8);
        ctx.fill();
        ctx.fillStyle = "#e8eef4";
        ctx.textAlign = "center";
        ctx.fillText(label, px, py + 5);
        ctx.textAlign = "left";
      }

      ctx.restore();
    };

    raf = requestAnimationFrame(loop);
    const sync = setInterval(() => {
      const p = pos.current;
      const s = useGame.getState();
      if (Math.abs(s.x - p.x) > 1 || Math.abs(s.y - p.y) > 1 || s.facing !== p.facing) {
        s.setPos(p.x, p.y, p.facing);
      }
    }, 180);

    const onVis = () => {
      if (document.hidden) useGame.getState().persist();
    };
    document.addEventListener("visibilitychange", onVis);

    return () => {
      cancelAnimationFrame(raf);
      unbind();
      clearInterval(sync);
      document.removeEventListener("visibilitychange", onVis);
      setInjectedKeys([]);
      touch.moveX = 0;
      touch.moveY = 0;
    };
  }, []);

  useEffect(() => {
    const unsub = useGame.subscribe((s, prev) => {
      if (s.roomId !== prev.roomId) {
        pos.current.x = s.x;
        pos.current.y = s.y;
        pos.current.facing = s.facing;
      }
    });
    return unsub;
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="h-full w-full touch-none"
      aria-label="Exploration"
    />
  );
}

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys: (codes: string[]) => void;
      getPos: () => { x: number; y: number };
    };
  }
}
