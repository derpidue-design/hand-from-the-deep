import { create } from "zustand";
import { ABILITIES } from "./content/combat";
import { CODEX, ITEMS } from "./content/items";
import { ROOMS } from "./content/rooms";
import { STORY } from "./content/story";
import { skipDejuir, startEncounter, useAbility, useItem } from "./systems/combatEngine";
import { sfxConfirm, sfxHit, sfxHurt, sfxNode, sfxUi, sfxWin } from "./systems/audio";
import { clearSave, defaultSave, loadSave, writeSave } from "./systems/save";
import type {
  AbilityDef,
  CombatState,
  Effect,
  EndingId,
  Facing,
  GameSave,
  InvItem,
  Screen,
} from "./types";

type GameStore = GameSave & {
  combat: CombatState | null;
  dialogueId: string | null;
  toast: string | null;
  paused: boolean;
  started: boolean;
  music: number;
  sfx: number;
  reduceMotion: boolean;
  newGame: () => void;
  continueGame: () => void;
  applySave: (s: GameSave) => void;
  persist: () => void;
  wipe: () => void;
  setScreen: (s: Screen) => void;
  setPaused: (v: boolean) => void;
  setPos: (x: number, y: number, facing: Facing) => void;
  addPlayMs: (ms: number) => void;
  startDialogue: (id: string) => void;
  advanceDialogue: (choiceIndex?: number) => void;
  applyEffects: (effects?: Effect[]) => void;
  interact: (kind: "hotspot" | "npc" | "exit", id: string) => void;
  pickAbility: (ability: AbilityDef, targetIndex: number) => void;
  pickItem: (itemId: string) => void;
  skipAlly: () => void;
  finishCombat: () => void;
  setVolumes: (music: number, sfx: number) => void;
  setReduceMotion: (v: boolean) => void;
  clearToast: () => void;
};

function resolveSkip(id: string): string | null {
  if (id === "maybe_voice") {
    if (useGame.getState().flags.heard_voice) return null;
    return "voice_check";
  }
  return id;
}

function clamp(n: number, a: number, b: number): number {
  return Math.max(a, Math.min(b, n));
}

function addItem(inv: InvItem[], id: string, qty = 1): InvItem[] {
  const i = inv.findIndex((x) => x.id === id);
  if (i >= 0) {
    const copy = inv.slice();
    copy[i] = { id, qty: copy[i]!.qty + qty };
    return copy;
  }
  return [...inv, { id, qty }];
}

function spendItem(inv: InvItem[], id: string): InvItem[] {
  return inv
    .map((x) => (x.id === id ? { ...x, qty: x.qty - 1 } : x))
    .filter((x) => x.qty > 0);
}

export const useGame = create<GameStore>((set, get) => ({
  ...defaultSave(),
  combat: null,
  dialogueId: null,
  toast: null,
  paused: false,
  started: false,
  music: 0.7,
  sfx: 0.8,
  reduceMotion: false,

  applySave: (s) => set({ ...s, combat: null, dialogueId: null, paused: false }),

  newGame: () => {
    const s = defaultSave();
    set({
      ...s,
      screen: "explore",
      combat: null,
      dialogueId: ROOMS.awakening?.intro ?? "wake_1",
      paused: false,
      toast: null,
      started: true,
    });
    get().persist();
  },

  continueGame: () => {
    const loaded = loadSave();
    if (!loaded) {
      get().newGame();
      return;
    }
    set({
      ...loaded,
      screen: loaded.ending ? "ending" : "explore",
      combat: null,
      dialogueId: null,
      paused: false,
      started: true,
    });
  },

  persist: () => {
    const s = get();
    writeSave({
      version: s.version,
      screen: s.ending ? "ending" : "explore",
      roomId: s.roomId,
      x: s.x,
      y: s.y,
      facing: s.facing,
      integrity: s.integrity,
      integrityMax: s.integrityMax,
      zinwave: s.zinwave,
      zinwaveMax: s.zinwaveMax,
      continuity: s.continuity,
      resonance: s.resonance,
      flags: s.flags,
      inventory: s.inventory,
      codex: s.codex,
      abilities: s.abilities,
      dejuirPresent: s.dejuirPresent,
      intEngine: s.intEngine,
      usedHotspots: s.usedHotspots,
      ending: s.ending,
      playMs: s.playMs,
    });
  },

  wipe: () => {
    clearSave();
    set({ ...defaultSave(), combat: null, dialogueId: null, paused: false, started: false, toast: "Sequence wiped." });
  },

  setScreen: (screen) => set({ screen, paused: false }),
  setPaused: (paused) => set({ paused }),
  setPos: (x, y, facing) => set({ x, y, facing }),
  addPlayMs: (ms) => set({ playMs: get().playMs + ms }),
  setVolumes: (music, sfx) => set({ music, sfx }),
  setReduceMotion: (reduceMotion) => set({ reduceMotion }),
  clearToast: () => set({ toast: null }),

  applyEffects: (effects) => {
    if (!effects?.length) return;
    const s = get();
    let next: Partial<GameStore> = {};
    const flags = { ...s.flags };
    let inventory = s.inventory.slice();
    const codex = s.codex.slice();
    const abilities = s.abilities.slice();
    let integrity = s.integrity;
    let integrityMax = s.integrityMax;
    let zinwave = s.zinwave;
    let zinwaveMax = s.zinwaveMax;
    let continuity = s.continuity;
    let resonance = s.resonance;
    let dejuirPresent = s.dejuirPresent;
    let intEngine = s.intEngine;
    let toast: string | null = s.toast;
    let roomId = s.roomId;
    let x = s.x;
    let y = s.y;
    let screen: Screen | undefined;
    let ending = s.ending;
    let dialogueId = s.dialogueId;
    let combat = s.combat;

    for (const e of effects) {
      if (e.type === "flag") flags[e.key] = e.value !== false;
      if (e.type === "stat") {
        if (e.stat === "integrity") integrity = clamp(integrity + e.delta, 0, integrityMax);
        if (e.stat === "zinwave") zinwave = clamp(zinwave + e.delta, 0, zinwaveMax);
        if (e.stat === "continuity") {
          continuity += e.delta;
          integrityMax = 92 + continuity * 3;
          zinwaveMax = 36 + Math.floor(continuity / 2) + resonance;
          integrity = clamp(integrity + 4, 0, integrityMax);
        }
        if (e.stat === "resonance") {
          resonance = Math.max(0, resonance + e.delta);
          zinwaveMax = 36 + Math.floor(continuity / 2) + resonance;
        }
      }
      if (e.type === "item") {
        inventory = addItem(inventory, e.id, e.qty ?? 1);
        const def = ITEMS[e.id];
        toast = def ? `Recovered: ${def.name}` : "Recovered an object.";
      }
      if (e.type === "codex" && !codex.includes(e.id)) {
        codex.push(e.id);
        toast = `Codex: ${CODEX[e.id]?.title ?? e.id}`;
      }
      if (e.type === "unlock" && !abilities.includes(e.ability)) {
        abilities.push(e.ability);
        toast = `Ability: ${ABILITIES[e.ability]?.name ?? e.ability}`;
      }
      if (e.type === "heal") integrity = clamp(integrity + e.amount, 0, integrityMax);
      if (e.type === "party") {
        if (e.dejuir !== undefined) dejuirPresent = e.dejuir;
        if (e.intEngine !== undefined) intEngine = e.intEngine;
      }
      if (e.type === "room") {
        roomId = e.id;
        x = e.x ?? ROOMS[e.id]?.spawn.x ?? x;
        y = e.y ?? ROOMS[e.id]?.spawn.y ?? y;
        screen = "explore";
        const intro = ROOMS[e.id]?.intro;
        if (intro && !flags[`intro_${e.id}`]) {
          flags[`intro_${e.id}`] = true;
          dialogueId = intro;
        } else {
          dialogueId = null;
        }
      }
      if (e.type === "ending") {
        ending = e.id as EndingId;
        screen = "ending";
        dialogueId = null;
      }
      if (e.type === "combat") {
        combat = startEncounter(e.encounter, {
          integrity,
          integrityMax,
          dejuir: dejuirPresent,
          intEngine,
          resonance,
        });
        combat.then = e.then;
        screen = "combat";
        dialogueId = null;
      }
    }

    zinwaveMax = 36 + Math.floor(continuity / 2) + resonance;
    zinwave = clamp(zinwave, 0, zinwaveMax);
    integrity = clamp(integrity, 0, integrityMax);

    next = {
      flags,
      inventory,
      codex,
      abilities,
      integrity,
      integrityMax,
      zinwave,
      zinwaveMax,
      continuity,
      resonance,
      dejuirPresent,
      intEngine,
      toast,
      roomId,
      x,
      y,
      ending,
      combat,
    };
    if (screen) next.screen = screen;
    if (dialogueId !== s.dialogueId) next.dialogueId = dialogueId;
    set(next);
    get().persist();
  },

  startDialogue: (id) => {
    const resolved = resolveSkip(id);
    if (!resolved || !STORY[resolved]) return;
    set({ dialogueId: resolved, screen: "explore" });
    sfxUi();
  },

  advanceDialogue: (choiceIndex) => {
    const id = get().dialogueId;
    if (!id) return;
    const node = STORY[id];
    if (!node) {
      set({ dialogueId: null });
      return;
    }
    if (node.choices && node.choices.length) {
      if (choiceIndex === undefined) return;
      const choice = node.choices[choiceIndex];
      if (!choice) return;
      sfxConfirm();
      get().applyEffects(choice.effects);
      if (get().ending || get().combat) {
        if (!get().combat) set({ dialogueId: null });
        return;
      }
      set({ dialogueId: resolveSkip(choice.next) });
      return;
    }
    get().applyEffects(node.effects);
    if (get().ending || get().combat) {
      if (!get().combat) set({ dialogueId: null });
      return;
    }
    if (node.next) {
      set({ dialogueId: resolveSkip(node.next) });
    } else {
      set({ dialogueId: null });
      get().persist();
    }
  },

  interact: (kind, id) => {
    const s = get();
    const room = ROOMS[s.roomId];
    if (!room) return;
    if (kind === "hotspot") {
      const hs = room.hotspots.find((h) => h.id === id);
      if (!hs) return;
      if (hs.requireFlag && !s.flags[hs.requireFlag]) return;
      if (hs.hideFlag && s.flags[hs.hideFlag]) return;
      if (hs.once && s.usedHotspots.includes(hs.id)) return;
      if (hs.once) set({ usedHotspots: [...s.usedHotspots, hs.id] });
      if (hs.dialogue) get().startDialogue(hs.dialogue);
    }
    if (kind === "npc") {
      const npc = room.npcs.find((n) => n.id === id);
      if (!npc?.dialogue) return;
      if (npc.requireFlag && !s.flags[npc.requireFlag]) return;
      if (npc.hideFlag && s.flags[npc.hideFlag]) return;
      get().startDialogue(npc.dialogue);
    }
    if (kind === "exit") {
      const ex = room.exits.find((e) => e.id === id);
      if (!ex) return;
      if (ex.requireFlag && !s.flags[ex.requireFlag]) {
        set({ toast: ex.lockedText ?? "Not yet." });
        return;
      }
      const dest = ROOMS[ex.to];
      if (!dest) return;
      const flags = { ...s.flags };
      let dialogueId: string | null = null;
      if (dest.intro && !flags[`intro_${dest.id}`]) {
        flags[`intro_${dest.id}`] = true;
        dialogueId = dest.intro;
      }
      set({
        roomId: dest.id,
        x: ex.spawnX,
        y: ex.spawnY,
        flags,
        dialogueId,
      });
      get().persist();
    }
  },

  pickAbility: (ability, targetIndex) => {
    const s = get();
    if (!s.combat) return;
    const { state, zinwave } = useAbility(s.combat, ability, targetIndex, s.zinwave);
    if (state.log.length > (s.combat.log.length ?? 0)) {
      const last = state.log[state.log.length - 1] ?? "";
      if (last.includes("takes") || last.includes("strikes")) sfxHit();
      else if (last.includes("screams") || last.includes("failing")) sfxHurt();
      else sfxNode();
    }
    const z2 = state.allies[0];
    set({
      combat: state,
      zinwave,
      integrity: z2?.hp ?? s.integrity,
    });
    if (state.result === "won") sfxWin();
    if (state.result === "lost") sfxHurt();
  },

  pickItem: (itemId) => {
    const s = get();
    if (!s.combat) return;
    const def = ITEMS[itemId];
    if (!def?.combat) return;
    const kind = def.combat.heal ? "heal" : def.combat.zinwave ? "zinwave" : "scan";
    const amount = def.combat.heal ?? def.combat.zinwave ?? 0;
    const { state, zinwave } = useItem(s.combat, kind, amount, s.zinwave);
    const z2 = state.allies[0];
    set({
      combat: state,
      zinwave,
      integrity: z2?.hp ?? s.integrity,
      inventory: spendItem(s.inventory, itemId),
    });
    sfxUi();
  },

  skipAlly: () => {
    const s = get();
    if (!s.combat) return;
    const state = skipDejuir(s.combat);
    const z2 = state.allies[0];
    set({ combat: state, integrity: z2?.hp ?? s.integrity });
  },

  finishCombat: () => {
    const s = get();
    const c = s.combat;
    if (!c) return;
    if (c.result === "lost") {
      set({
        combat: null,
        integrity: Math.max(12, Math.floor(s.integrityMax * 0.4)),
        roomId: s.roomId,
        dialogueId: null,
        toast: "The node rebooted. Sequence restored at a cost.",
        screen: "explore",
      });
      get().persist();
      return;
    }
    const z2 = c.allies[0];
    set({
      combat: null,
      integrity: z2?.hp ?? s.integrity,
      screen: "explore",
      dialogueId: c.then ?? null,
    });
    get().persist();
  },
}));
