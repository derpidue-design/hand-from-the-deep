import { useCallback, useRef } from "react";
import { touch } from "../systems/input";
import { useGame } from "../store";

export function TouchControls() {
  const origin = useRef<{ x: number; y: number; id: number } | null>(null);
  const dialogueId = useGame((s) => s.dialogueId);
  const combat = useGame((s) => s.combat);
  const paused = useGame((s) => s.paused);

  const steer = useCallback((x: number, y: number) => {
    const o = origin.current;
    if (!o) return;
    const dx = x - o.x;
    const dy = y - o.y;
    const mag = Math.hypot(dx, dy);
    const max = 48;
    const nx = mag > max ? (dx / mag) * max : dx;
    const ny = mag > max ? (dy / mag) * max : dy;
    touch.moveX = nx / max;
    touch.moveY = ny / max;
  }, []);

  const release = useCallback(() => {
    origin.current = null;
    touch.moveX = 0;
    touch.moveY = 0;
  }, []);

  if (dialogueId || combat || paused) return null;

  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 z-20 flex items-end justify-between p-3 sm:hidden">
      <div
        className="pointer-events-auto relative h-32 w-32 touch-none rounded-full border border-line bg-void/50"
        onPointerDown={(e) => {
          (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
          const r = e.currentTarget.getBoundingClientRect();
          origin.current = { x: r.left + r.width / 2, y: r.top + r.height / 2, id: e.pointerId };
          steer(e.clientX, e.clientY);
        }}
        onPointerMove={(e) => {
          if (!origin.current || origin.current.id !== e.pointerId) return;
          steer(e.clientX, e.clientY);
        }}
        onPointerUp={release}
        onPointerCancel={release}
      >
        <span className="pointer-events-none absolute inset-0 m-auto h-10 w-10 rounded-full border border-line-strong" />
      </div>
      <button
        type="button"
        className="pointer-events-auto min-h-16 min-w-16 rounded-full border border-line-strong bg-frost/90 text-sm font-medium text-void"
        onPointerDown={(e) => {
          e.preventDefault();
          touch.interact = true;
        }}
        onPointerUp={() => {
          touch.interact = false;
        }}
        onPointerCancel={() => {
          touch.interact = false;
        }}
      >
        E
      </button>
    </div>
  );
}
