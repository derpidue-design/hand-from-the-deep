import { CODEX, ITEMS } from "../content/items";
import { useGame } from "../store";
import { setVolumes } from "../systems/audio";

export function PauseMenu() {
  const paused = useGame((s) => s.paused);
  const screen = useGame((s) => s.screen);
  const setPaused = useGame((s) => s.setPaused);
  const setScreen = useGame((s) => s.setScreen);
  const persist = useGame((s) => s.persist);
  const wipe = useGame((s) => s.wipe);
  const inventory = useGame((s) => s.inventory);
  const codex = useGame((s) => s.codex);
  const music = useGame((s) => s.music);
  const sfx = useGame((s) => s.sfx);
  const reduceMotion = useGame((s) => s.reduceMotion);
  const setVol = useGame((s) => s.setVolumes);
  const setReduce = useGame((s) => s.setReduceMotion);
  const started = useGame((s) => s.started);

  const panel =
    screen === "codex" || screen === "inventory" || screen === "settings" ? screen : "pause";
  const visible =
    screen !== "title" &&
    screen !== "ending" &&
    (paused || screen === "settings" || screen === "codex" || screen === "inventory");

  if (!visible) return null;

  return (
    <div className="absolute inset-0 z-50 flex items-end justify-center bg-void/70 p-3 sm:items-center">
      <div className="max-h-[88dvh] w-full max-w-lg overflow-auto rounded-xl border border-line bg-glass p-5">
        <div className="flex items-start justify-between gap-3">
          <h2 className="font-display text-3xl text-frost">
            {panel === "codex" ? "Codex" : panel === "inventory" ? "Recovered" : panel === "settings" ? "Settings" : "Menu"}
          </h2>
          <button
            type="button"
            className="min-h-11 rounded-md border border-line px-3 text-sm text-muted"
            onClick={() => {
              if (!started) setScreen("title");
              else {
                setScreen("explore");
                setPaused(false);
              }
            }}
          >
            Close
          </button>
        </div>

        {(panel === "pause" || panel === "settings") && (
          <div className="mt-5 flex flex-col gap-4">
            <label className="block text-sm text-muted">
              Music
              <input
                type="range"
                min={0}
                max={1}
                step={0.01}
                value={music}
                className="mt-2 w-full accent-signal"
                onChange={(e) => {
                  const v = Number(e.target.value);
                  setVol(v, sfx);
                  setVolumes(0.7, v, sfx);
                }}
              />
            </label>
            <label className="block text-sm text-muted">
              Effects
              <input
                type="range"
                min={0}
                max={1}
                step={0.01}
                value={sfx}
                className="mt-2 w-full accent-signal"
                onChange={(e) => {
                  const v = Number(e.target.value);
                  setVol(music, v);
                  setVolumes(0.7, music, v);
                }}
              />
            </label>
            <label className="flex min-h-11 items-center gap-2 text-sm text-frost">
              <input
                type="checkbox"
                checked={reduceMotion}
                onChange={(e) => setReduce(e.target.checked)}
              />
              Reduce motion
            </label>
          </div>
        )}

        {panel === "pause" && (
          <div className="mt-5 flex flex-col gap-2">
            <button
              type="button"
              className="rounded-md bg-frost px-4 py-3 text-sm font-medium text-void"
              onClick={() => {
                persist();
                setPaused(false);
              }}
            >
              Resume
            </button>
            <button
              type="button"
              className="rounded-md border border-line px-4 py-3 text-sm text-frost"
              onClick={() => {
                persist();
                setPaused(false);
                setScreen("title");
              }}
            >
              Title
            </button>
            <button
              type="button"
              className="rounded-md border border-line px-4 py-3 text-left text-sm text-frost"
              onClick={() => setScreen("inventory")}
            >
              Inventory
            </button>
            <button
              type="button"
              className="rounded-md border border-line px-4 py-3 text-left text-sm text-frost"
              onClick={() => setScreen("codex")}
            >
              Codex
            </button>
          </div>
        )}

        {(panel === "inventory" || (panel === "pause" && false)) && (
          <ul className="mt-4 flex flex-col gap-3">
            {inventory.length === 0 ? (
              <li className="text-sm text-muted">Nothing recovered yet.</li>
            ) : (
              inventory.map((it) => (
                <li key={it.id} className="rounded-md border border-line bg-raised p-3">
                  <p className="text-sm text-frost">
                    {ITEMS[it.id]?.name ?? it.id}{" "}
                    <span className="font-mono text-muted">×{it.qty}</span>
                  </p>
                  <p className="mt-1 text-sm leading-relaxed text-muted">{ITEMS[it.id]?.desc}</p>
                </li>
              ))
            )}
          </ul>
        )}

        {panel === "codex" && (
          <ul className="mt-4 flex flex-col gap-3">
            {codex.length === 0 ? (
              <li className="text-sm text-muted">No entries. They will appear as you remember.</li>
            ) : (
              codex.map((id) => (
                <li key={id} className="rounded-md border border-line bg-raised p-3">
                  <p className="font-mono text-[10px] tracking-widest text-signal uppercase">
                    Part {CODEX[id]?.chapter}
                  </p>
                  <p className="font-display text-xl text-frost">{CODEX[id]?.title}</p>
                  <p className="mt-2 text-sm leading-relaxed text-muted">{CODEX[id]?.body}</p>
                </li>
              ))
            )}
          </ul>
        )}

        {panel === "settings" && fromTitle && (
          <button
            type="button"
            className="mt-6 rounded-md border border-danger/40 px-4 py-3 text-sm text-danger"
            onClick={() => {
              wipe();
              setScreen("title");
            }}
          >
            Wipe saved sequence
          </button>
        )}
      </div>
    </div>
  );
}
