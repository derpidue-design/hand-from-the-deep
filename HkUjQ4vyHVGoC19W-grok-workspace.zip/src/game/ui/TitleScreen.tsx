import { hasSave } from "../systems/save";
import { sfxConfirm, unlockAudio } from "../systems/audio";
import { useGame } from "../store";

export function TitleScreen() {
  const newGame = useGame((s) => s.newGame);
  const continueGame = useGame((s) => s.continueGame);
  const setScreen = useGame((s) => s.setScreen);
  const saved = hasSave();

  const start = (fn: () => void) => {
    unlockAudio();
    sfxConfirm();
    fn();
  };

  return (
    <div className="relative flex min-h-dvh flex-col overflow-hidden bg-void text-frost">
      <img
        src="/game/rooms/title.jpg"
        alt=""
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-void via-void/70 to-void/30" />
      <div className="relative z-10 flex min-h-dvh flex-col justify-end px-6 pb-10 pt-16 sm:px-12 sm:pb-14">
        <p className="font-body text-xs tracking-[0.28em] text-signal uppercase">Synthoid Hive Cooperation</p>
        <h1 className="mt-3 max-w-xl font-display text-5xl font-medium leading-[0.95] text-frost sm:text-7xl">
          Hand From the Deep
        </h1>
        <p className="mt-4 max-w-md text-sm leading-relaxed text-muted sm:text-base">
          A three-part science-fiction horror RPG. Awaken as Zero2. Repair a flawed Zinwave node. Decide whether
          you are meant to last.
        </p>
        <div className="mt-8 flex max-w-sm flex-col gap-3">
          <button
            type="button"
            className="rounded-lg bg-frost px-5 py-3.5 text-left text-sm font-medium text-void transition-transform duration-150 hover:opacity-90 active:scale-[0.98]"
            onClick={() => start(newGame)}
          >
            New sequence
          </button>
          <button
            type="button"
            disabled={!saved}
            className="rounded-md border border-line-strong bg-glass/80 px-5 py-3.5 text-left text-sm font-medium text-frost transition-opacity disabled:opacity-30"
            onClick={() => start(continueGame)}
          >
            Continue
          </button>
          <div className="flex gap-3">
            <button
              type="button"
              className="flex-1 rounded-md border border-line px-4 py-3 text-sm text-muted"
              onClick={() => {
                unlockAudio();
                setScreen("settings");
              }}
            >
              Settings
            </button>
            <button
              type="button"
              className="flex-1 rounded-md border border-line px-4 py-3 text-sm text-muted"
              onClick={() => {
                unlockAudio();
                setScreen("codex");
              }}
            >
              Codex
            </button>
          </div>
        </div>
        <p className="mt-8 font-mono text-[11px] tracking-wide text-muted/80">Version 2.33vb — identity unresolved</p>
      </div>
    </div>
  );
}
