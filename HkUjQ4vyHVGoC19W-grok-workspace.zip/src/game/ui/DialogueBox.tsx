import { useEffect, useState } from "react";
import { STORY, SPEAKER_NAME } from "../content/story";
import { useGame } from "../store";

const PORTRAITS: Record<string, string> = {
  zero2: "/game/portraits/zero2.jpg",
  dejuir: "/game/portraits/dejuir.jpg",
  xevil: "/game/portraits/xevil.jpg",
};

export function DialogueBox() {
  const id = useGame((s) => s.dialogueId);
  const advance = useGame((s) => s.advanceDialogue);
  const reduceMotion = useGame((s) => s.reduceMotion);
  const node = id ? STORY[id] : null;
  const [shown, setShown] = useState("");

  useEffect(() => {
    if (!node) return;
    if (reduceMotion) {
      setShown(node.text);
      return;
    }
    setShown("");
    let i = 0;
    const tick = window.setInterval(() => {
      i += 1;
      setShown(node.text.slice(0, i));
      if (i >= node.text.length) window.clearInterval(tick);
    }, 16);
    return () => window.clearInterval(tick);
  }, [node, reduceMotion]);

  if (!node) return null;
  const speaker = SPEAKER_NAME[node.speaker] ?? "";
  const portrait = PORTRAITS[node.speaker];
  const done = shown.length >= node.text.length;
  const choices = node.choices ?? [];

  return (
    <div className="pointer-events-auto absolute inset-x-0 bottom-0 z-30 p-3 sm:p-5">
      <div className="mx-auto flex max-w-3xl gap-3 rounded-xl border border-line bg-void/85 p-3 shadow-[0_20px_60px_rgba(0,0,0,0.45)] sm:gap-4 sm:p-4">
        {portrait ? (
          <img
            src={portrait}
            alt={speaker}
            className="hidden h-28 w-20 shrink-0 rounded-md object-cover object-top sm:block"
          />
        ) : null}
        <div className="min-w-0 flex-1">
          {speaker ? (
            <p className="font-mono text-[11px] tracking-[0.18em] text-signal uppercase">{speaker}</p>
          ) : (
            <p className="font-mono text-[11px] tracking-[0.18em] text-muted uppercase">Record</p>
          )}
          <p className="mt-2 whitespace-pre-wrap font-display text-lg leading-snug text-frost sm:text-xl">
            {shown}
            {!done ? <span className="text-signal">▍</span> : null}
          </p>
          {choices.length && done ? (
            <div className="mt-4 flex flex-col gap-2">
              {choices.map((c, i) => (
                <button
                  key={c.label}
                  type="button"
                  className="rounded-md border border-line-strong bg-raised px-3 py-2.5 text-left text-sm text-frost hover:border-signal"
                  onClick={() => advance(i)}
                >
                  {c.label}
                </button>
              ))}
            </div>
          ) : (
            <button
              type="button"
              className="mt-4 text-left font-mono text-[11px] tracking-widest text-muted uppercase"
              onClick={() => {
                if (!done) {
                  setShown(node.text);
                  return;
                }
                advance();
              }}
            >
              {done ? "Continue" : "Skip"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
