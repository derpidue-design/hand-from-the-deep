import { abilityList, ENCOUNTERS } from "../content/combat";
import { ITEMS } from "../content/items";
import { useGame } from "../store";
import type { AbilityDef } from "../types";

export function CombatScreen() {
  const combat = useGame((s) => s.combat);
  const abilities = useGame((s) => s.abilities);
  const inventory = useGame((s) => s.inventory);
  const zinwave = useGame((s) => s.zinwave);
  const pickAbility = useGame((s) => s.pickAbility);
  const pickItem = useGame((s) => s.pickItem);
  const skipAlly = useGame((s) => s.skipAlly);
  const finishCombat = useGame((s) => s.finishCombat);
  const intEngine = useGame((s) => s.intEngine);

  if (!combat) return null;
  const enc = ENCOUNTERS[combat.encounterId];
  const actor = combat.turn === "dejuir" ? "dejuir" : "zero2";
  const list = abilityList(abilities, actor).filter((a) => {
    if (a.id === "anchor" && combat.usedAnchor) return false;
    if (a.unlock === "int_engine" && !intEngine && a.id !== "resonance") {
      /* still listed if unlocked via abilities array */
    }
    return true;
  });
  const foes = combat.enemies.filter((e) => e.hp > 0);
  const z2 = combat.allies[0];
  const dej = combat.allies.find((a) => a.id === "dejuir");
  const consumables = inventory.filter((i) => ITEMS[i.id]?.combat);

  const fire = (a: AbilityDef) => {
    pickAbility(a, 0);
  };

  return (
    <div className="absolute inset-0 z-40 flex flex-col bg-void">
      <img
        src={enc?.background ?? "/game/rooms/arena.jpg"}
        alt=""
        className="absolute inset-0 h-full w-full object-cover opacity-50"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-void via-void/70 to-void/40" />
      <div className="relative flex min-h-0 flex-1 flex-col p-3 sm:p-5">
        <p className="font-mono text-[11px] tracking-[0.22em] text-signal uppercase">{enc?.name}</p>
        <div className="mt-3 flex flex-wrap gap-3">
          {combat.enemies.map((e) => (
            <div key={e.id} className="min-w-[9rem] flex-1 rounded-md border border-line bg-glass/80 p-3">
              <p className="font-display text-lg text-frost">{e.name}</p>
              <p className="font-mono text-[10px] text-muted uppercase">{e.kind}</p>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-raised">
                <div
                  className="h-full bg-danger"
                  style={{ width: `${(e.hp / e.hpMax) * 100}%` }}
                />
              </div>
              <p className="mt-1 font-mono text-[10px] tabular-nums text-muted">
                {e.hp} / {e.hpMax}
                {e.stunned > 0 ? " · staggered" : ""}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-4 min-h-0 flex-1 overflow-auto rounded-md border border-line bg-void/60 p-3 font-mono text-xs leading-relaxed text-muted">
          {combat.log.map((line, i) => (
            <p key={`${i}-${line.slice(0, 12)}`} className="text-frost/85">
              {line}
            </p>
          ))}
        </div>

        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <div className="rounded-md border border-line bg-glass/85 p-3">
            <p className="font-display text-lg text-frost">{z2?.name}</p>
            <p className="font-mono text-[10px] tabular-nums text-muted">
              Integrity {z2?.hp}/{z2?.hpMax} · Zinwave {zinwave} · Shield {z2?.shield ?? 0}
            </p>
            {dej ? (
              <p className="mt-1 font-mono text-[10px] tabular-nums text-amber">
                De'juir {dej.hp}/{dej.hpMax}
              </p>
            ) : null}
            {intEngine ? <p className="mt-1 font-mono text-[10px] text-gold">I.N.T. Engine active</p> : null}
          </div>
          <div className="rounded-md border border-line bg-glass/85 p-3">
            {combat.result === "pending" ? (
              <>
                <p className="font-mono text-[10px] tracking-widest text-signal uppercase">
                  {combat.turn === "dejuir" ? "De'juir's action" : "Zero2's action"}
                </p>
                <div className="mt-2 grid grid-cols-2 gap-2">
                  {list.map((a) => (
                    <button
                      key={a.id}
                      type="button"
                      disabled={zinwave < a.cost || !foes.length}
                      className="rounded-md border border-line-strong bg-raised px-2 py-2 text-left disabled:opacity-35"
                      onClick={() => fire(a)}
                    >
                      <span className="block text-sm text-frost">{a.name}</span>
                      <span className="block font-mono text-[10px] text-muted">
                        {a.cost ? `${a.cost} ZN` : "0"} {a.damage ? `· ${a.damage}` : ""} {a.heal ? `· +${a.heal}` : ""}
                      </span>
                    </button>
                  ))}
                  {combat.turn === "player"
                    ? consumables.map((it) => (
                        <button
                          key={it.id}
                          type="button"
                          className="rounded-md border border-line px-2 py-2 text-left"
                          onClick={() => pickItem(it.id)}
                        >
                          <span className="block text-sm text-frost">{ITEMS[it.id]?.name}</span>
                          <span className="block font-mono text-[10px] text-muted">Use ×{it.qty}</span>
                        </button>
                      ))
                    : null}
                  {combat.turn === "dejuir" ? (
                    <button
                      type="button"
                      className="rounded-md border border-line px-2 py-2 text-sm text-muted"
                      onClick={skipAlly}
                    >
                      Hold position
                    </button>
                  ) : null}
                </div>
              </>
            ) : (
              <div>
                <p className="font-display text-xl text-frost">
                  {combat.result === "won" ? "The sequence holds." : "Identity sequence failing."}
                </p>
                <button
                  type="button"
                  className="mt-3 min-h-11 rounded-md bg-frost px-4 py-2 text-sm font-medium text-void"
                  onClick={finishCombat}
                >
                  Continue
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
