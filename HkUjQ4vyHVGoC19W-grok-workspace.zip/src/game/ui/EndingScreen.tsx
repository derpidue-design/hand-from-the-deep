import { useGame } from "../store";

const COPY: Record<string, { title: string; body: string; img: string }> = {
  canon: {
    title: "The signal remains",
    img: "/game/rooms/folds.jpg",
    body: "A lone Synthoid travels through a reality that may be artificial, carrying the consciousness of the machine who once protected her. Ahead lies a signal from the unknown. Behind her lies a darkness that may not have finished reaching for her. Somewhere between existence and deletion, a hand is still waiting.",
  },
  dark: {
    title: "What is owed",
    img: "/game/rooms/deep.jpg",
    body: "She let go. The Deep closed. De'juir's amber sensor did not return. Zero2 was taken beyond the sequence — a clean, perfect silence, purchased with the only hand that had told her she was here.",
  },
  sanctuary: {
    title: "The dream that remained",
    img: "/game/rooms/vrp.jpg",
    body: "The V.R.P. holds. Isolation protocols remain active. De'juir's continuum is quiet inside the I.N.T. Engine. Outside the golden water, a broken circle still pulses. They do not answer. Not yet.",
  },
};

export function EndingScreen() {
  const ending = useGame((s) => s.ending) ?? "canon";
  const continuity = useGame((s) => s.continuity);
  const resonance = useGame((s) => s.resonance);
  const setScreen = useGame((s) => s.setScreen);
  const persist = useGame((s) => s.persist);
  const data = COPY[ending] ?? COPY.canon;

  return (
    <div className="relative flex min-h-dvh flex-col bg-void text-frost">
      <img src={data.img} alt="" className="absolute inset-0 h-full w-full object-cover opacity-50" />
      <div className="absolute inset-0 bg-gradient-to-t from-void via-void/80 to-void/40" />
      <div className="relative z-10 mx-auto flex min-h-dvh max-w-xl flex-col justify-end px-6 py-12">
        <p className="font-mono text-[11px] tracking-[0.24em] text-signal uppercase">End of Hand From the Deep</p>
        <h1 className="mt-3 font-display text-5xl leading-tight">{data.title}</h1>
        <p className="mt-4 text-sm leading-relaxed text-muted sm:text-base">{data.body}</p>
        <p className="mt-6 font-mono text-[11px] text-muted">
          Continuity {continuity} · Resonance {resonance}
        </p>
        <button
          type="button"
          className="mt-8 min-h-11 rounded-lg bg-frost px-5 py-3 text-sm font-medium text-void"
          onClick={() => {
            persist();
            setScreen("title");
          }}
        >
          Return to title
        </button>
      </div>
    </div>
  );
}
