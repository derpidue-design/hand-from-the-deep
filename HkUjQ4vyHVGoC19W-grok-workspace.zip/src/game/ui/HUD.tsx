import { useGame } from "../store";
import { ROOMS } from "../content/rooms";

function Bar({
  value,
  max,
  label,
  tone,
}: {
  value: number;
  max: number;
  label: string;
  tone: "signal" | "node" | "amber";
}) {
  const pct = max <= 0 ? 0 : Math.max(0, Math.min(100, (value / max) * 100));
  const fill = tone === "signal" ? "bg-signal" : tone === "node" ? "bg-node" : "bg-amber";
  return (
    <div className="min-w-0">
      <div className="mb-1 flex justify-between font-mono text-[10px] tracking-wider text-muted uppercase">
        <span>{label}</span>
        <span className="tabular-nums text-frost/80">
          {Math.round(value)}/{Math.round(max)}
        </span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-raised">
        <div className={`h-full ${fill}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

export function HUD() {
  const integrity = useGame((s) => s.integrity);
  const integrityMax = useGame((s) => s.integrityMax);
  const zinwave = useGame((s) => s.zinwave);
  const zinwaveMax = useGame((s) => s.zinwaveMax);
  const continuity = useGame((s) => s.continuity);
  const resonance = useGame((s) => s.resonance);
  const roomId = useGame((s) => s.roomId);
  const intEngine = useGame((s) => s.intEngine);
  const setPaused = useGame((s) => s.setPaused);
  const room = ROOMS[roomId];

  return (
    <div className="pointer-events-none absolute inset-0 z-20">
      <div className="flex items-start justify-between gap-3 p-3 sm:p-4">
        <div className="pointer-events-auto w-[min(100%,18rem)] rounded-lg border border-line bg-void/75 p-3">
          <p className="font-mono text-[10px] tracking-[0.2em] text-signal uppercase">{room?.part}</p>
          <p className="mt-0.5 font-display text-lg text-frost">{room?.name}</p>
          <div className="mt-3 flex flex-col gap-2">
            <Bar value={integrity} max={integrityMax} label="Integrity" tone="signal" />
            <Bar value={zinwave} max={zinwaveMax} label="Zinwave" tone="node" />
          </div>
          <div className="mt-3 flex gap-4 font-mono text-[10px] tracking-wide text-muted uppercase">
            <span>
              Continuity <span className="tabular-nums text-frost">{continuity}</span>
            </span>
            <span>
              Resonance <span className="tabular-nums text-frost">{resonance}</span>
            </span>
            {intEngine ? <span className="text-gold">I.N.T.</span> : null}
          </div>
        </div>
        <button
          type="button"
          className="pointer-events-auto min-h-11 min-w-11 rounded-md border border-line bg-void/75 px-3 font-mono text-[11px] tracking-widest text-frost uppercase"
          onClick={() => setPaused(true)}
        >
          Menu
        </button>
      </div>
    </div>
  );
}
