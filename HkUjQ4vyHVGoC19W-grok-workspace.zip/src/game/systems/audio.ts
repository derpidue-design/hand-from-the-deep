type Bus = { ctx: AudioContext; master: GainNode; music: GainNode; sfx: GainNode };

let bus: Bus | null = null;
let drone: { osc: OscillatorNode; filt: BiquadFilterNode; lfo: OscillatorNode; gain: GainNode } | null =
  null;
let ambience: "chamber" | "corridor" | "deep" | "void" | "gold" | "folds" | "title" | "off" = "off";

function ensure(): Bus | null {
  if (typeof window === "undefined") return null;
  if (bus) return bus;
  const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!AC) return null;
  const ctx = new AC({ latencyHint: "interactive" });
  const master = ctx.createGain();
  const music = ctx.createGain();
  const sfx = ctx.createGain();
  master.gain.value = 0.7;
  music.gain.value = 0.22;
  sfx.gain.value = 0.45;
  music.connect(master);
  sfx.connect(master);
  master.connect(ctx.destination);
  bus = { ctx, master, music, sfx };
  return bus;
}

export function unlockAudio(): void {
  const b = ensure();
  if (!b) return;
  if (b.ctx.state === "suspended") void b.ctx.resume();
}

export function setVolumes(master: number, music: number, sfx: number): void {
  const b = bus;
  if (!b) return;
  const t = b.ctx.currentTime;
  b.master.gain.setTargetAtTime(master * master, t, 0.04);
  b.music.gain.setTargetAtTime(music * music, t, 0.04);
  b.sfx.gain.setTargetAtTime(sfx * sfx, t, 0.04);
}

export function resumeAudio(): void {
  if (bus && bus.ctx.state === "suspended") void bus.ctx.resume();
}

function beep(freq: number, dur: number, type: OscillatorType, gain = 0.08, slide?: number): void {
  const b = bus;
  if (!b) return;
  const o = b.ctx.createOscillator();
  const g = b.ctx.createGain();
  o.type = type;
  o.frequency.value = freq;
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), b.ctx.currentTime + dur);
  g.gain.value = 0.0001;
  g.gain.setTargetAtTime(gain, b.ctx.currentTime, 0.01);
  g.gain.setTargetAtTime(0.0001, b.ctx.currentTime + dur * 0.7, 0.05);
  o.connect(g);
  g.connect(b.sfx);
  o.start();
  o.stop(b.ctx.currentTime + dur + 0.05);
  o.onended = () => {
    o.disconnect();
    g.disconnect();
  };
}

export function sfxUi(): void {
  beep(620, 0.07, "sine", 0.04);
}
export function sfxConfirm(): void {
  beep(440, 0.1, "triangle", 0.05, 180);
}
export function sfxHit(): void {
  beep(140, 0.14, "square", 0.07, -80);
}
export function sfxHurt(): void {
  beep(220, 0.16, "sawtooth", 0.05, -120);
}
export function sfxNode(): void {
  beep(880, 0.18, "sine", 0.05, 400);
}
export function sfxWin(): void {
  beep(520, 0.2, "triangle", 0.06, 260);
}

export function setAmbience(next: typeof ambience): void {
  const b = ensure();
  if (!b) return;
  if (next === ambience && drone) return;
  ambience = next;
  if (drone) {
    try {
      drone.osc.stop();
      drone.lfo.stop();
    } catch {
      /* already stopped */
    }
    drone = null;
  }
  if (next === "off") return;
  const map: Record<string, { f: number; q: number; lfo: number }> = {
    title: { f: 72, q: 8, lfo: 0.08 },
    chamber: { f: 64, q: 6, lfo: 0.06 },
    corridor: { f: 88, q: 10, lfo: 0.12 },
    deep: { f: 42, q: 4, lfo: 0.05 },
    void: { f: 38, q: 3, lfo: 0.04 },
    gold: { f: 96, q: 12, lfo: 0.07 },
    folds: { f: 110, q: 14, lfo: 0.09 },
  };
  const m = map[next] ?? map.chamber;
  const osc = b.ctx.createOscillator();
  const filt = b.ctx.createBiquadFilter();
  const gain = b.ctx.createGain();
  const lfo = b.ctx.createOscillator();
  const lfoGain = b.ctx.createGain();
  osc.type = "sine";
  osc.frequency.value = m.f;
  filt.type = "lowpass";
  filt.frequency.value = 240;
  filt.Q.value = m.q;
  gain.gain.value = 0.0001;
  gain.gain.setTargetAtTime(0.22, b.ctx.currentTime, 0.6);
  lfo.frequency.value = m.lfo;
  lfoGain.gain.value = 18;
  lfo.connect(lfoGain);
  lfoGain.connect(osc.frequency);
  osc.connect(filt);
  filt.connect(gain);
  gain.connect(b.music);
  osc.start();
  lfo.start();
  drone = { osc, filt, lfo, gain };
}
