import type { GameSave } from "../types";

const KEY = "hfd.save.v1";
const BACKUP = "hfd.save.v1.bak";
export const SAVE_VERSION = 1;

export function defaultSave(): GameSave {
  return {
    version: SAVE_VERSION,
    screen: "title",
    roomId: "awakening",
    x: 640,
    y: 470,
    facing: "down",
    integrity: 92,
    integrityMax: 92,
    zinwave: 36,
    zinwaveMax: 36,
    continuity: 0,
    resonance: 0,
    flags: {},
    inventory: [],
    codex: [],
    abilities: ["pulse", "hold", "intercept", "stabilize", "lock"],
    dejuirPresent: false,
    intEngine: false,
    usedHotspots: [],
    playMs: 0,
  };
}

function migrate(raw: GameSave): GameSave {
  const base = defaultSave();
  return {
    ...base,
    ...raw,
    version: SAVE_VERSION,
    flags: { ...raw.flags },
    inventory: Array.isArray(raw.inventory) ? raw.inventory : [],
    codex: Array.isArray(raw.codex) ? raw.codex : [],
    abilities: Array.isArray(raw.abilities) ? raw.abilities : base.abilities,
    usedHotspots: Array.isArray(raw.usedHotspots) ? raw.usedHotspots : [],
  };
}

export function loadSave(): GameSave | null {
  try {
    const raw = localStorage.getItem(KEY) ?? localStorage.getItem(BACKUP);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as GameSave;
    if (!parsed || typeof parsed !== "object") return null;
    return migrate(parsed);
  } catch {
    return null;
  }
}

export function writeSave(save: GameSave): void {
  try {
    const prev = localStorage.getItem(KEY);
    if (prev) localStorage.setItem(BACKUP, prev);
    localStorage.setItem(KEY, JSON.stringify({ ...save, version: SAVE_VERSION }));
  } catch {
    /* private mode / quota */
  }
}

export function clearSave(): void {
  try {
    localStorage.removeItem(KEY);
    localStorage.removeItem(BACKUP);
  } catch {
    /* ignore */
  }
}

export function hasSave(): boolean {
  try {
    return Boolean(localStorage.getItem(KEY) || localStorage.getItem(BACKUP));
  } catch {
    return false;
  }
}
