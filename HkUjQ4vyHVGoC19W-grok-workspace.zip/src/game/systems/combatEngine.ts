import { ABILITIES, ENCOUNTERS, ENEMIES } from "../content/combat";
import type { AbilityDef, CombatState, Combatant } from "../types";

let seq = 1;
function uid(prefix: string): string {
  seq += 1;
  return `${prefix}-${seq}`;
}

function roll(min: number, max: number): number {
  return min + Math.floor(Math.random() * (max - min + 1));
}

function tickStatus(c: Combatant): string[] {
  const notes: string[] = [];
  c.status = c.status
    .map((s) => ({ ...s, turns: s.turns - 1 }))
    .filter((s) => {
      if (s.turns < 0) {
        notes.push(`${c.name} is no longer ${s.id}.`);
        return false;
      }
      return true;
    });
  if (c.stunned > 0) c.stunned -= 1;
  if (c.shield > 0) c.shield = Math.max(0, c.shield - 2);
  return notes;
}

function applyDamage(target: Combatant, amount: number): number {
  let dmg = Math.max(1, amount - target.def);
  if (target.shield > 0) {
    const used = Math.min(target.shield, dmg);
    target.shield -= used;
    dmg -= used;
  }
  target.hp = Math.max(0, target.hp - dmg);
  return dmg;
}

export function startEncounter(
  id: string,
  opts: { integrity: number; integrityMax: number; dejuir: boolean; intEngine: boolean; resonance: number },
): CombatState {
  const enc = ENCOUNTERS[id];
  if (!enc) throw new Error(`Missing encounter ${id}`);
  const allies: Combatant[] = [
    {
      id: "zero2",
      name: "Zero2",
      hp: opts.integrity,
      hpMax: opts.integrityMax,
      atk: 8 + Math.floor(opts.resonance / 2),
      def: 2,
      shield: 0,
      kind: "ally",
      status: [],
      stunned: 0,
    },
  ];
  if (enc.allyDejuir && opts.dejuir) {
    allies.push({
      id: "dejuir",
      name: "De'juir",
      hp: 70 + opts.resonance * 2,
      hpMax: 70 + opts.resonance * 2,
      atk: 7,
      def: 4,
      shield: 0,
      kind: "ally",
      status: [],
      stunned: 0,
    });
  }
  const enemies: Combatant[] = enc.enemies.map((eid, i) => {
    const def = ENEMIES[eid]!;
    return {
      id: uid(def.id),
      name: enc.enemies.length > 1 ? `${def.name} ${i + 1}` : def.name,
      hp: def.hp,
      hpMax: def.hp,
      atk: def.atk,
      def: def.def,
      shield: 0,
      kind: def.kind,
      status: [],
      stunned: 0,
    };
  });
  return {
    encounterId: id,
    allies,
    enemies,
    turn: "player",
    log: [enc.intro],
    selecting: true,
    result: "pending",
    usedAnchor: false,
  };
}

export function living(list: Combatant[]): Combatant[] {
  return list.filter((c) => c.hp > 0);
}

function finishCheck(state: CombatState): CombatState {
  if (living(state.enemies).length === 0) {
    return { ...state, result: "won", selecting: false, log: [...state.log, "The sequence holds."] };
  }
  if ((state.allies[0]?.hp ?? 0) <= 0) {
    return { ...state, result: "lost", selecting: false, log: [...state.log, "Identity sequence failing."] };
  }
  return state;
}

export function useAbility(state: CombatState, ability: AbilityDef, targetIndex: number, zinwave: number): {
  state: CombatState;
  zinwave: number;
} {
  if (state.result !== "pending" || !state.selecting) return { state, zinwave };
  if (ability.id === "anchor" && state.usedAnchor) return { state, zinwave };
  if (zinwave < ability.cost) {
    return { state: { ...state, log: [...state.log, "Zinwave insufficient."] }, zinwave };
  }

  const next: CombatState = {
    ...state,
    allies: state.allies.map((a) => ({ ...a, status: [...a.status] })),
    enemies: state.enemies.map((e) => ({ ...e, status: [...e.status] })),
    log: [...state.log],
  };
  const actor = ability.actor === "dejuir" ? next.allies.find((a) => a.id === "dejuir") : next.allies[0];
  if (!actor || actor.hp <= 0) return { state, zinwave };

  let z = zinwave - ability.cost;
  const foes = living(next.enemies);
  const targets =
    ability.target === "allEnemies"
      ? foes
      : ability.target === "enemy"
        ? [foes[Math.max(0, Math.min(targetIndex, foes.length - 1))]].filter(Boolean)
        : ability.target === "ally"
          ? [next.allies[0]]
          : [actor];

  const logs: string[] = [`${actor.name} uses ${ability.name}.`];
  if (ability.selfDamage) {
    const sd = applyDamage(actor, ability.selfDamage);
    logs.push(`The node screams. ${sd} integrity lost.`);
  }
  if (ability.shield) {
    const who = ability.target === "ally" ? next.allies[0] : actor;
    who.shield += ability.shield;
    logs.push(`A brace forms around ${who.name} (+${ability.shield}).`);
  }
  if (ability.heal) {
    const who = ability.target === "ally" ? next.allies[0]! : actor;
    who.hp = Math.min(who.hpMax, who.hp + ability.heal);
    logs.push(`${who.name} restores ${ability.heal} integrity.`);
  }
  for (const t of targets) {
    if (!t) continue;
    if (ability.damage) {
      const dmg = applyDamage(t, ability.damage + Math.floor(actor.atk / 3) + roll(0, 4));
      logs.push(`${t.name} takes ${dmg}.`);
    }
    if (ability.stagger) t.stunned += ability.stagger;
    if (ability.status) t.status.push({ ...ability.status });
  }
  if (ability.id === "anchor") next.usedAnchor = true;

  next.log = [...next.log, ...logs].slice(-10);
  const after = finishCheck(next);
  if (after.result !== "pending") return { state: after, zinwave: z };

  if (ability.actor === "zero2" && next.allies.some((a) => a.id === "dejuir" && a.hp > 0)) {
    return { state: { ...after, turn: "dejuir", selecting: true }, zinwave: z };
  }
  return { state: enemyTurn({ ...after, turn: "enemy", selecting: false }), zinwave: z };
}

export function useItem(
  state: CombatState,
  kind: "heal" | "zinwave" | "scan",
  amount: number,
  zinwave: number,
): { state: CombatState; zinwave: number; scanned?: string } {
  const next: CombatState = {
    ...state,
    allies: state.allies.map((a) => ({ ...a })),
    enemies: state.enemies.map((e) => ({ ...e })),
    log: [...state.log],
  };
  const z2 = next.allies[0]!;
  let z = zinwave;
  let scanned: string | undefined;
  if (kind === "heal") {
    z2.hp = Math.min(z2.hpMax, z2.hp + amount);
    next.log.push(`Repair compound restores ${amount}.`);
  } else if (kind === "zinwave") {
    z = Math.min(99, z + amount);
    next.log.push("The calibrator steadies the node.");
  } else {
    const foe = living(next.enemies)[0];
    scanned = foe ? `${foe.name} intends to strike. ATK ${foe.atk}.` : "No target.";
    next.log.push(scanned);
  }
  next.log = next.log.slice(-10);
  return { state: next, zinwave: z, scanned };
}

export function skipDejuir(state: CombatState): CombatState {
  return enemyTurn({ ...state, turn: "enemy", selecting: false });
}

export function enemyTurn(state: CombatState): CombatState {
  const next: CombatState = {
    ...state,
    allies: state.allies.map((a) => ({ ...a, status: [...a.status] })),
    enemies: state.enemies.map((e) => ({ ...e, status: [...e.status] })),
    log: [...state.log],
  };
  for (const a of next.allies) next.log.push(...tickStatus(a));
  for (const e of next.enemies) next.log.push(...tickStatus(e));

  const z2 = next.allies[0]!;
  const dej = next.allies.find((a) => a.id === "dejuir" && a.hp > 0);
  for (const foe of living(next.enemies)) {
    if (foe.stunned > 0) {
      next.log.push(`${foe.name} cannot hold a shape.`);
      continue;
    }
    const def = Object.values(ENEMIES).find((d) => foe.name.startsWith(d.name));
    const phrase = def?.phrases[roll(0, (def.phrases.length || 1) - 1)];
    if (phrase) next.log.push(`${foe.name}: “${phrase}”`);
    let target = z2;
    if (foe.kind === "parasite" && dej) target = dej;
    else if (dej && dej.shield > 0) target = dej;
    else if (dej && Math.random() < 0.25) target = dej;
    const dmg = applyDamage(target, foe.atk + roll(0, 3));
    next.log.push(`${foe.name} strikes ${target.name} for ${dmg}.`);
    if (z2.hp <= 0) break;
  }
  next.log = next.log.slice(-10);
  const after = finishCheck(next);
  if (after.result !== "pending") return after;
  return { ...after, turn: "player", selecting: true };
}
