export type Actions = {
  moveX: number;
  moveY: number;
  interact: boolean;
  pause: boolean;
  confirm: boolean;
};

const GAME_KEYS = new Set([
  "KeyW",
  "KeyA",
  "KeyS",
  "KeyD",
  "ArrowUp",
  "ArrowLeft",
  "ArrowDown",
  "ArrowRight",
  "KeyE",
  "Space",
  "Enter",
  "Escape",
  "KeyI",
  "KeyJ",
  "KeyC",
]);

const keys = new Set<string>();
let injected: string[] | null = null;
let prevInteract = false;
let prevPause = false;
let prevConfirm = false;

export const touch = {
  moveX: 0,
  moveY: 0,
  interact: false,
  pause: false,
};

function held(): Set<string> {
  if (injected) return new Set(injected);
  return keys;
}

function radial(x: number, y: number, dz = 0.15): { x: number; y: number } {
  const m = Math.hypot(x, y);
  if (m < dz) return { x: 0, y: 0 };
  const scale = (m - dz) / (1 - dz) / m;
  return { x: x * scale, y: y * scale };
}

export function pollActions(): Actions & { interactPressed: boolean; pausePressed: boolean; confirmPressed: boolean } {
  const k = held();
  let x = touch.moveX;
  let y = touch.moveY;
  if (k.has("KeyA") || k.has("ArrowLeft")) x -= 1;
  if (k.has("KeyD") || k.has("ArrowRight")) x += 1;
  if (k.has("KeyW") || k.has("ArrowUp")) y -= 1;
  if (k.has("KeyS") || k.has("ArrowDown")) y += 1;

  const pads = typeof navigator !== "undefined" ? navigator.getGamepads?.() ?? [] : [];
  for (const pad of pads) {
    if (!pad) continue;
    const st = radial(pad.axes[0] ?? 0, pad.axes[1] ?? 0);
    x += st.x;
    y += st.y;
    if (pad.buttons[12]?.pressed) y -= 1;
    if (pad.buttons[13]?.pressed) y += 1;
    if (pad.buttons[14]?.pressed) x -= 1;
    if (pad.buttons[15]?.pressed) x += 1;
  }

  const mag = Math.hypot(x, y);
  if (mag > 1) {
    x /= mag;
    y /= mag;
  }

  const interact =
    k.has("KeyE") || k.has("Space") || touch.interact || pads.some((p) => p?.buttons[0]?.pressed);
  const pause = k.has("Escape") || touch.pause || pads.some((p) => p?.buttons[9]?.pressed);
  const confirm = k.has("Enter") || k.has("Space") || pads.some((p) => p?.buttons[0]?.pressed);

  const interactPressed = interact && !prevInteract;
  const pausePressed = pause && !prevPause;
  const confirmPressed = confirm && !prevConfirm;
  prevInteract = interact;
  prevPause = pause;
  prevConfirm = confirm;

  return {
    moveX: x,
    moveY: y,
    interact: Boolean(interact),
    pause: Boolean(pause),
    confirm: Boolean(confirm),
    interactPressed,
    pausePressed,
    confirmPressed,
  };
}

export function setInjectedKeys(codes: string[]): void {
  injected = codes.length ? codes : null;
}

export function bindInput(target: Window | HTMLElement): () => void {
  const down = (e: KeyboardEvent) => {
    keys.add(e.code);
    if (GAME_KEYS.has(e.code)) e.preventDefault();
  };
  const up = (e: KeyboardEvent) => {
    keys.delete(e.code);
  };
  const clear = () => keys.clear();
  target.addEventListener("keydown", down as EventListener);
  target.addEventListener("keyup", up as EventListener);
  window.addEventListener("blur", clear);
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) clear();
  });
  return () => {
    target.removeEventListener("keydown", down as EventListener);
    target.removeEventListener("keyup", up as EventListener);
    window.removeEventListener("blur", clear);
  };
}
