import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { GameApp } from "@/game/GameApp";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  if (!ready) {
    return (
      <main className="flex min-h-dvh items-end bg-void px-8 py-12 text-frost">
        <div>
          <p className="font-mono text-[11px] tracking-[0.24em] text-signal uppercase">Z.I.N. STATUS: ACTIVE</p>
          <h1 className="mt-2 font-display text-4xl">Hand From the Deep</h1>
        </div>
      </main>
    );
  }
  return <GameApp />;
}
