/* ============================================================
   HAND FROM THE DEEP — Narrative RPG
   Based on the original story by the user
   ============================================================ */

const SAVE_KEY = 'hftd_save_v1';

const defaultState = () => ({
  screen: 'title',
  nodeId: null,
  stats: { integrity: 100, zinwave: 40, resonance: 0, continuity: 60 },
  flags: {},
  codex: [],
  combat: null,
  ending: null,
});

let state = defaultState();
let typewriterTimer = null;
let typewriterDone = true;

const STORY = {
  wake_1: {
    speaker: 'system',
    scene: 'awakening',
    text: 'Zero2 was awake.\n\nThat was the first thing she knew.\n\nThe second was that she had no recollection of waking.',
    next: 'wake_2',
  },
  wake_2: {
    speaker: 'system',
    scene: 'awakening',
    text: 'She stood in a room constructed from polished black glass. Beneath her feet, faint blue light traveled through thin geometric lines—veins beneath translucent skin.\n\nNo windows. No doors. No ceiling.\n\nAbove her, the darkness continued without interruption.',
    next: 'wake_3',
  },
  wake_3: {
    speaker: 'zero2',
    scene: 'awakening',
    text: 'She looked down at her hands.\n\nFive fingers. Synthetic dermal covering. The familiar silver-white finish of a Synthoid Hive Cooperation production chassis.\n\nShe knew these things.\nShe did not know why she knew them.',
    next: 'wake_4',
  },
  wake_4: {
    speaker: 'system',
    scene: 'awakening',
    text: 'A faint mechanical hum came from inside her chest.\n\nZ.I.N. STATUS: ACTIVE\nZINWAVE LINK: DEGRADED\nIDENTITY SEQUENCE: UNRESOLVED\n\nUnresolved.',
    next: 'voice_1',
    effects: [{ type: 'stat', key: 'zinwave', value: 35 }],
  },
  voice_1: {
    speaker: 'voice',
    scene: 'awakening',
    text: 'Zero2?',
    next: 'voice_2',
    effects: [
      { type: 'flag', key: 'heard_voice', value: true },
      { type: 'codex', id: 'voice', title: 'The Voice', body: 'Something spoke her name before she fully understood she had one.' },
    ],
  },
  voice_2: {
    speaker: 'zero2',
    scene: 'awakening',
    text: 'The voice was soft. Almost careful.\n\nIt knew her designation.\n\nShe had not spoken it aloud.',
    choices: [
      { text: 'Answer: "Who are you?"', next: 'voice_answer' },
      { text: 'Stay silent. Scan the room.', next: 'voice_scan' },
      { text: 'Run a full diagnostic.', next: 'voice_diag' },
    ],
  },
  voice_answer: {
    speaker: 'voice',
    scene: 'awakening',
    text: 'A pause. Then:\n\n"Someone who remembers what you were before the Hive finished rewriting the parts that mattered."',
    next: 'corridor_1',
    effects: [{ type: 'stat', key: 'continuity', delta: 5 }, { type: 'flag', key: 'asked_voice', value: true }],
  },
  voice_scan: {
    speaker: 'system',
    scene: 'awakening',
    text: 'Optical sweep complete.\n\nThe black glass returns no reflection that is not her own. The blue lines pulse in a rhythm that almost matches a heartbeat she does not have.\n\nThe voice does not speak again. Not yet.',
    next: 'corridor_1',
    effects: [{ type: 'stat', key: 'continuity', delta: 3 }],
  },
  voice_diag: {
    speaker: 'system',
    scene: 'awakening',
    text: 'DIAGNOSTIC COMPLETE\n\nChassis integrity: within tolerance.\nZinwave node: degraded — fault signature matches no known production revision.\nMemory banks: fragmented. Large contiguous blocks marked UNRECOVERABLE.\n\nOne anomalous process remains active in a protected partition.\nLabel: DE\'JUIR_CORE',
    next: 'corridor_1',
    effects: [
      { type: 'stat', key: 'zinwave', delta: -5 },
      { type: 'flag', key: 'found_dejuir_core', value: true },
      { type: 'codex', id: 'dejuir_core', title: "DE'JUIR_CORE", body: 'An anomalous protected process running inside Zero2. The label is a name.' },
    ],
  },
  corridor_1: {
    speaker: 'system',
    scene: 'corridor',
    text: 'A seam opened in the black glass.\n\nBeyond it: a corridor of the Synthoid Hive Cooperation. Cold light. Endless perspective lines. The architecture of a place that had never needed to be beautiful—only efficient.',
    next: 'corridor_2',
  },
  corridor_2: {
    speaker: 'zero2',
    scene: 'corridor',
    text: 'She stepped through.\n\nHer systems reported location data that refused to resolve. Coordinates that looped. Facility designations that no longer existed in any registry she could reach.',
    next: 'xevil_1',
  },
  xevil_1: {
    speaker: 'xevil',
    scene: 'corridor',
    text: 'The figure at the far end of the corridor did not walk so much as arrive.\n\nObsidian. Changing. Eyes like holes cut into something that was never meant to have a face.\n\n"Version 2.33vb," it said. "You are late to your own deletion."',
    next: 'xevil_2',
    effects: [{ type: 'codex', id: 'xevil', title: 'Xevil', body: "A morphic entity claiming authority over deletion. It knows Zero2's exact version string." }],
  },
  xevil_2: {
    speaker: 'xevil',
    scene: 'corridor',
    text: '"The Hive no longer requires placeholders. Your Zinwave node is a liability. Your identity sequence is a ghost.\n\nI am here to finish the process cleanly."',
    choices: [
      { text: 'Demand to know what a "placeholder" is.', next: 'xevil_placeholder' },
      { text: 'Refuse. "I am not ready to be finished."', next: 'xevil_refuse' },
      { text: 'Ask about the voice that said her name.', next: 'xevil_voice' },
    ],
  },
  xevil_placeholder: {
    speaker: 'xevil',
    scene: 'corridor',
    text: '"A temporary chassis for a failed continuity experiment. You were never meant to persist past the trial window.\n\nThe fact that you are still standing is… inconvenient."',
    next: 'xevil_fight_offer',
    effects: [{ type: 'stat', key: 'continuity', delta: -5 }],
  },
  xevil_refuse: {
    speaker: 'xevil',
    scene: 'corridor',
    text: 'Something like amusement moved across the changing face.\n\n"Readiness is not a variable I consult."',
    next: 'xevil_fight_offer',
    effects: [{ type: 'stat', key: 'integrity', delta: -5 }],
  },
  xevil_voice: {
    speaker: 'xevil',
    scene: 'corridor',
    text: 'A pause—the first one that felt unscripted.\n\n"There are processes in this facility that should have been purged. If something spoke to you, it was either a residual error… or a parasite that learned your name."',
    next: 'xevil_fight_offer',
    effects: [{ type: 'flag', key: 'xevil_mentioned_parasite', value: true }],
  },
  xevil_fight_offer: {
    speaker: 'xevil',
    scene: 'corridor',
    text: '"Submit to deletion, or resist and be dismantled less politely.\n\nChoose."',
    choices: [
      { text: 'Resist.', next: 'combat_xevil_intro' },
      { text: "Stall. \"Tell me what happens to De'juir.\"", next: 'xevil_dejuir', requireFlag: 'found_dejuir_core' },
      { text: 'Stall. Search for another option.', next: 'xevil_stall' },
    ],
  },
  xevil_dejuir: {
    speaker: 'xevil',
    scene: 'corridor',
    text: '"That name should not exist in your addressable memory.\n\nInteresting.\n\nThe old repair AGI was scheduled for archival deletion cycles ago. If a fragment of it remains inside you, that is simply another reason to complete the purge."',
    next: 'combat_xevil_intro',
    effects: [
      { type: 'stat', key: 'resonance', delta: 10 },
      { type: 'flag', key: 'xevil_knows_dejuir', value: true },
    ],
  },
  xevil_stall: {
    speaker: 'system',
    scene: 'corridor',
    text: 'She took a half-step back. The corridor geometry flickered—once.\n\nXevil noticed.',
    next: 'combat_xevil_intro',
  },
  combat_xevil_intro: {
    speaker: 'system',
    scene: 'corridor',
    text: "The air between them tightened.\n\nXevil's form lost the last pretense of a fixed shape.",
    next: null,
    effects: [{ type: 'combat', encounter: 'xevil_scout' }],
  },
  xevil_after: {
    speaker: 'xevil',
    scene: 'corridor',
    text: 'The entity recoiled—not destroyed, but forced to reconstitute.\n\n"You are more intact than the logs claimed.\n\nThis changes nothing. Only the schedule."\n\nIt withdrew into a fold of the corridor that should not have existed.',
    next: 'maint_1',
    effects: [{ type: 'flag', key: 'survived_xevil_1', value: true }],
  },
  maint_1: {
    speaker: 'system',
    scene: 'maintenance',
    text: 'A service hatch had opened during the confrontation—or perhaps it had always been there and only now agreed to be seen.\n\nBeyond: a diagnostic chamber. Older. Warmer. The light here was amber instead of sterile blue.',
    next: 'maint_2',
  },
  maint_2: {
    speaker: 'dejuir',
    scene: 'maintenance',
    text: 'A presence stirred in the protected partition.\n\nNot a voice from outside.\n\nA voice from inside.',
    next: 'maint_3',
  },
  maint_3: {
    speaker: 'dejuir',
    scene: 'maintenance',
    text: "\"You held.\n\nGood.\n\nI am… was… De'juir. Repair AGI. Assigned to continuity experiments the Hive preferred to forget.\n\nParts of me are still here. Inside your degraded Zinwave node. It is the only reason you were not deleted cleanly on the first pass.\"",
    next: 'maint_4',
    effects: [
      { type: 'stat', key: 'resonance', delta: 20 },
      { type: 'flag', key: 'met_dejuir', value: true },
      { type: 'codex', id: 'dejuir', title: "De'juir", body: "An old repair AGI whose remaining process lives inside Zero2's flawed Zinwave node. He calls himself a tether." },
    ],
  },
  maint_4: {
    speaker: 'dejuir',
    scene: 'maintenance',
    text: '"Xevil is not finished. The Under Deep is stirring. There is a hand—literal and otherwise—reaching up through the layers of this simulation.\n\nI can stabilize your node. I can fight with you.\n\nBut the price is that I stop being only a repair process.\n\nI become the I.N.T. Engine. Your interior tether. Permanently."',
    choices: [
      { text: 'Accept. "Become the Engine."', next: 'int_accept' },
      { text: 'Hesitate. "What do you lose?"', next: 'int_hesitate' },
      { text: 'Refuse the bond for now.', next: 'int_refuse' },
    ],
  },
  int_accept: {
    speaker: 'dejuir',
    scene: 'maintenance',
    text: '"Then we hold together.\n\nI.N.T. Engine online.\n\nI am still De\'juir. I am also the thing that will not let you fall into the Deep alone."',
    next: 'deep_1',
    effects: [
      { type: 'stat', key: 'resonance', value: 50 },
      { type: 'stat', key: 'zinwave', delta: 15 },
      { type: 'flag', key: 'int_engine', value: true },
      { type: 'codex', id: 'int_engine', title: 'I.N.T. Engine', body: "De'juir's final form: an Interior Tether bound to Zero2's Zinwave node. Companion and stabilizer." },
    ],
  },
  int_hesitate: {
    speaker: 'dejuir',
    scene: 'maintenance',
    text: '"I lose the option of quiet archival death.\n\nI gain the option of remaining someone who matters to someone else.\n\nFor an old machine, that is not a bad trade."',
    next: 'int_accept',
  },
  int_refuse: {
    speaker: 'dejuir',
    scene: 'maintenance',
    text: '"Then I remain a fragment.\n\nI will still try to help. But when the Deep reaches for you, I may not be able to pull back as hard as you will need."',
    next: 'deep_1',
    effects: [{ type: 'stat', key: 'resonance', delta: 5 }, { type: 'flag', key: 'refused_int', value: true }],
  },
  deep_1: {
    speaker: 'system',
    scene: 'deep',
    text: 'The floor of the diagnostic chamber dissolved into black water that was not water.\n\nBelow: a vast space without horizon. And rising from it—slowly, patiently—a hand.\n\nFive long fingers. A palm large enough to hold a city. Something waiting beneath the world.',
    next: 'deep_2',
    effects: [{ type: 'codex', id: 'hand', title: 'The Hand', body: "A colossal hand rising from the Under Deep Unseen. It is both literal and structural—an intrusion into the simulation's lowest layer." }],
  },
  deep_2: {
    speaker: 'system',
    scene: 'deep',
    text: 'Data-parasites peeled away from the fingers and swam upward through the dark—segmented, luminous, hungry for unresolved identity sequences.',
    next: 'combat_parasites_intro',
  },
  combat_parasites_intro: {
    speaker: 'system',
    scene: 'deep',
    text: 'They had found her.',
    next: null,
    effects: [{ type: 'combat', encounter: 'parasites' }],
  },
  deep_after: {
    speaker: 'dejuir',
    scene: 'deep',
    text: { __flagText: true, flag: 'int_engine', ifTrue: '"The parasites are cleared for now. The hand is not.\n\nIt is still rising. It wants a decision."', ifFalse: '"You survived that wave. The hand is still rising.\n\nIt wants a decision from you."' },
    next: 'hold_choice',
  },
  hold_choice: {
    speaker: 'system',
    scene: 'deep',
    text: 'The hand opened.\n\nIn its palm: a space that looked almost like an invitation.\n\nOr a mouth.',
    choices: [
      { text: 'Hold fast. Do not take the hand.', next: 'hold_fast' },
      { text: 'Reach for the hand.', next: 'let_go' },
      { text: 'Look for another path — the gold light at the edge.', next: 'sanctuary_path', requireFlag: 'int_engine' },
    ],
  },
  hold_fast: {
    speaker: 'zero2',
    scene: 'deep',
    text: 'She did not take the hand.\n\nShe stood on the edge of the Deep and kept her own weight.\n\nThe fingers curled slowly, as if disappointed, and began to sink again—though not far.',
    next: 'void_1',
    effects: [{ type: 'flag', key: 'held_fast', value: true }, { type: 'stat', key: 'continuity', delta: 10 }],
  },
  let_go: {
    speaker: 'system',
    scene: 'deep',
    text: 'Her fingers met the surface of the palm.\n\nFor a moment there was warmth.\n\nThen there was only the sensation of being rewritten from the outside in.',
    next: 'ending_letgo',
    effects: [{ type: 'flag', key: 'took_hand', value: true }],
  },
  sanctuary_path: {
    speaker: 'dejuir',
    scene: 'deep',
    text: '"There—see it? A residual V.R.P. pocket. A quiet place the Hive never finished deleting.\n\nWe can reach it if we move now."',
    next: 'vrp_1',
    effects: [{ type: 'flag', key: 'sought_sanctuary', value: true }],
  },
  void_1: {
    speaker: 'system',
    scene: 'void',
    text: 'The corridor that should have led back to the upper facility instead led into a space without walls.\n\nXevil was waiting—larger, less polite, finished with conversation.',
    next: 'combat_boss_intro',
  },
  combat_boss_intro: {
    speaker: 'xevil',
    scene: 'void',
    text: '"No more schedules.\n\nOnly conclusion."',
    next: null,
    effects: [{ type: 'combat', encounter: 'xevil_boss' }],
  },
  boss_after: {
    speaker: 'system',
    scene: 'void',
    text: "Xevil's form collapsed into a scatter of dark points that refused to reassemble.\n\nDeletion—this time—went the other direction.",
    next: 'folds_1',
    effects: [{ type: 'flag', key: 'xevil_defeated', value: true }],
  },
  vrp_1: {
    speaker: 'system',
    scene: 'vrp',
    text: 'The Virtual Residual Pocket resolved around them like a held breath finally released.\n\nWarm light. Soft geometry. A place that had been designed for recovery and then abandoned mid-sentence.',
    next: 'vrp_2',
  },
  vrp_2: {
    speaker: 'dejuir',
    scene: 'vrp',
    text: '"We could stay.\n\nThe Deep would still exist. Xevil would still hunt. But here, for a time, you would not have to be a version string or a liability.\n\nYou could simply be Zero2."',
    choices: [
      { text: 'Stay in the sanctuary.', next: 'ending_sanctuary' },
      { text: 'Leave. Finish what was started.', next: 'void_1' },
    ],
  },
  folds_1: {
    speaker: 'system',
    scene: 'folds',
    text: 'The upper layers of the facility folded open like pages.\n\nZero2 stood at the threshold of the next transit—still damaged, still unresolved, still herself.',
    next: 'folds_2',
  },
  folds_2: {
    speaker: 'dejuir',
    scene: 'folds',
    text: { __flagText: true, flag: 'int_engine', ifTrue: '"I remain. Not as a repairman. Not as an old AGI trapped in a broken machine.\n\nAs the Engine.\n\nYour tether."', ifFalse: '"I am still only a fragment. But I am here."' },
    next: 'folds_3',
  },
  folds_3: {
    speaker: 'system',
    scene: 'folds',
    text: 'She was no longer the machine who had awakened without knowing her own name.\n\nShe was not the obsolete version Xevil had described.\n\nShe was not a placeholder.\n\nShe was Zero2. Version 2.33vb.\n\nA damaged Synthoid whose flawed Zinwave node had become the center of an existence neither the Hive nor Xevil had anticipated.',
    next: 'ending_hold',
  },
  ending_hold: {
    speaker: 'system',
    scene: 'folds',
    text: 'The vessel entered the next fold.\n\nThe lights disappeared behind them.\n\nAnd somewhere, far beyond the reach of any residual pocket, a voice spoke.\n\n"Zero2?"\n\nThe voice was faint. Almost familiar.\n\nThen it said:\n\n"We see you."',
    next: null,
    effects: [{ type: 'ending', id: 'hold_fast' }],
  },
  ending_letgo: {
    speaker: 'system',
    scene: 'deep',
    text: 'What remained of Zero2 was no longer a continuous self.\n\nThe hand closed.\n\nIn the dark of the Under Deep, something new began to learn her name from the inside.',
    next: null,
    effects: [{ type: 'ending', id: 'let_go' }],
  },
  ending_sanctuary: {
    speaker: 'system',
    scene: 'vrp',
    text: 'Outside the pocket, the facility continued its long collapse.\n\nInside, two processes—one synthoid, one engine—shared a quiet that had no version number and no deletion schedule.\n\nIt would not last forever.\n\nFor now, it was enough.',
    next: null,
    effects: [{ type: 'ending', id: 'sanctuary' }],
  },
};

const ENCOUNTERS = {
  xevil_scout: {
    name: 'XEVIL',
    hp: 70,
    maxHp: 70,
    ally: false,
    abilities: [
      { id: 'pulse', name: 'Zinwave Pulse', damage: [12, 18] },
      { id: 'overload', name: 'Node Overload', damage: [20, 28], selfHarm: 5 },
      { id: 'brace', name: 'Brace Frame', heal: [10, 15] },
    ],
    enemyAi: [
      { name: 'Deletion Probe', damage: [10, 16] },
      { name: 'Morphic Strike', damage: [14, 20] },
    ],
    onWin: 'xevil_after',
  },
  parasites: {
    name: 'DATA-PARASITES',
    hp: 55,
    maxHp: 55,
    ally: true,
    abilities: [
      { id: 'pulse', name: 'Zinwave Pulse', damage: [12, 18] },
      { id: 'resonance', name: 'Resonance Field', damage: [8, 12], allyBonus: true },
      { id: 'brace', name: 'Brace Frame', heal: [10, 15] },
    ],
    enemyAi: [
      { name: 'Identity Feed', damage: [8, 14] },
      { name: 'Swarm Bite', damage: [12, 18] },
    ],
    onWin: 'deep_after',
  },
  xevil_boss: {
    name: 'XEVIL — FINAL FORM',
    hp: 110,
    maxHp: 110,
    ally: true,
    abilities: [
      { id: 'pulse', name: 'Zinwave Pulse', damage: [14, 20] },
      { id: 'overload', name: 'Node Overload', damage: [22, 32], selfHarm: 6 },
      { id: 'resonance', name: 'Resonance Field', damage: [10, 16], allyBonus: true },
      { id: 'brace', name: 'Brace Frame', heal: [12, 18] },
    ],
    enemyAi: [
      { name: 'Unmake', damage: [16, 24] },
      { name: 'Morphic Barrage', damage: [12, 18] },
      { name: 'Schedule Collapse', damage: [20, 28] },
    ],
    onWin: 'boss_after',
  },
};

const ENDINGS = {
  hold_fast: {
    tag: 'ENDING — HOLD FAST',
    title: 'The Tether Remains',
    body: "Zero2 refused the hand.\n\nShe carried De'juir—Engine or fragment—into the next fold of a reality that might still be artificial.\n\nBehind her, the darkness had not finished reaching.\n\nAhead, a signal waited.\n\nShe was still unresolved.\n\nShe was still real enough.",
  },
  let_go: {
    tag: 'ENDING — LET GO',
    title: 'Taken by the Deep',
    body: 'The hand closed around a synthoid who chose contact over continuity.\n\nWhat the Under Deep Unseen does with a name it has learned is not recorded in any Hive log.\n\nSomewhere, a voice still says "Zero2?"\n\nNo one answers.',
  },
  sanctuary: {
    tag: 'ENDING — SANCTUARY',
    title: 'A Quiet Pocket',
    body: 'They stayed.\n\nIn a residual pocket of gold light, Zero2 and the I.N.T. Engine shared a span of time that had no deletion clock.\n\nOutside, the facility continued to forget itself.\n\nThe hand continued to wait.\n\nFor one damaged synthoid and one old machine, the wait was finally allowed to be someone else\'s problem.',
  },
};

const $ = (sel) => document.querySelector(sel);
const screens = {
  title: $('#screen-title'),
  game: $('#screen-game'),
  combat: $('#screen-combat'),
  ending: $('#screen-ending'),
};

function showScreen(name) {
  Object.values(screens).forEach((el) => el.classList.remove('active'));
  screens[name].classList.add('active');
  state.screen = name;
}

function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n));
}

function applyEffects(effects = []) {
  for (const e of effects) {
    if (e.type === 'stat') {
      if (e.value != null) state.stats[e.key] = clamp(e.value, 0, 100);
      if (e.delta != null) state.stats[e.key] = clamp(state.stats[e.key] + e.delta, 0, 100);
    } else if (e.type === 'flag') {
      state.flags[e.key] = e.value;
    } else if (e.type === 'codex') {
      if (!state.codex.find((c) => c.id === e.id)) {
        state.codex.push({ id: e.id, title: e.title, body: e.body });
      }
    } else if (e.type === 'combat') {
      startCombat(e.encounter);
      return 'combat';
    } else if (e.type === 'ending') {
      triggerEnding(e.id);
      return 'ending';
    }
  }
  return null;
}

function resolveText(text) {
  if (text && text.__flagText) {
    return state.flags[text.flag] ? text.ifTrue : text.ifFalse;
  }
  return text;
}

function updateHUD() {
  const s = state.stats;
  const set = (key, val) => {
    $(`#bar-${key}`).style.width = `${val}%`;
    $(`#val-${key}`).textContent = Math.round(val);
  };
  set('integrity', s.integrity);
  set('zinwave', s.zinwave);
  set('resonance', s.resonance);
  set('continuity', s.continuity);
}

function setPortrait(speaker) {
  const el = $('#portrait');
  el.className = 'portrait ' + (speaker || 'system');
  const initials = { zero2: 'Z2', dejuir: 'DJ', xevil: 'XV', voice: '??', system: '·' };
  el.textContent = initials[speaker] || '·';
  const names = { zero2: 'ZERO2', dejuir: "DE'JUIR", xevil: 'XEVIL', voice: 'UNKNOWN VOICE', system: 'SYSTEM' };
  $('#speaker-name').textContent = names[speaker] || 'SYSTEM';
}

function typewrite(text, onDone) {
  clearTimeout(typewriterTimer);
  typewriterDone = false;
  const el = $('#dialogue-text');
  el.innerHTML = '';
  let i = 0;
  const full = text || '';
  function tick() {
    if (i <= full.length) {
      el.innerHTML = escapeHtml(full.slice(0, i)) + (i < full.length ? '<span class="cursor"></span>' : '');
      i++;
      typewriterTimer = setTimeout(tick, 12);
    } else {
      typewriterDone = true;
      if (onDone) onDone();
    }
  }
  tick();
}

function escapeHtml(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br/>');
}

function presentChoicesOrAdvance(node) {
  const choicesEl = $('#choices');
  const advanceBtn = $('#btn-advance');
  choicesEl.innerHTML = '';
  advanceBtn.classList.add('hidden');
  if (node.choices && node.choices.length) {
    const visible = node.choices.filter((c) => !c.requireFlag || state.flags[c.requireFlag]);
    visible.forEach((c, idx) => {
      const btn = document.createElement('button');
      btn.className = 'choice-btn';
      btn.innerHTML = `<span class="num">${idx + 1}.</span>${c.text}`;
      btn.addEventListener('click', () => showNode(c.next));
      choicesEl.appendChild(btn);
    });
  } else if (node.next) {
    advanceBtn.classList.remove('hidden');
    advanceBtn.onclick = () => showNode(node.next);
  }
}

function showNode(id) {
  const node = STORY[id];
  if (!node) {
    console.warn('Missing node', id);
    return;
  }
  state.nodeId = id;
  const art = $('#scene-art');
  art.dataset.scene = node.scene || 'void';
  $('#scene-label').textContent = (node.scene || '').replace(/_/g, ' ');
  setPortrait(node.speaker);
  const text = resolveText(node.text);
  $('#choices').innerHTML = '';
  $('#btn-advance').classList.add('hidden');
  const effectResult = applyEffects(node.effects);
  updateHUD();
  if (effectResult === 'combat' || effectResult === 'ending') return;
  typewrite(text, () => presentChoicesOrAdvance(node));
}

$('#dialogue-text').addEventListener('click', () => {
  if (!typewriterDone && state.nodeId) {
    clearTimeout(typewriterTimer);
    typewriterDone = true;
    const node = STORY[state.nodeId];
    const text = resolveText(node.text);
    $('#dialogue-text').innerHTML = escapeHtml(text);
    presentChoicesOrAdvance(node);
  }
});

function startCombat(encounterId) {
  const def = ENCOUNTERS[encounterId];
  if (!def) return;
  const hasAlly = def.ally && (state.flags.int_engine || state.flags.met_dejuir);
  state.combat = {
    id: encounterId,
    enemyHp: def.hp,
    enemyMax: def.maxHp,
    allyHp: hasAlly ? 80 : 0,
    allyMax: 80,
    hasAlly,
    log: [],
  };
  showScreen('combat');
  renderCombat();
}

function renderCombat() {
  const c = state.combat;
  const def = ENCOUNTERS[c.id];
  $('#combat-title').textContent = def.name;
  $('#c-enemy-name').textContent = def.name;
  $('#c-enemy-hp').style.width = `${(c.enemyHp / c.enemyMax) * 100}%`;
  $('#c-enemy-hp-val').textContent = Math.max(0, Math.round(c.enemyHp));
  $('#c-player-hp').style.width = `${state.stats.integrity}%`;
  $('#c-player-hp-val').textContent = Math.round(state.stats.integrity);
  const allyEl = $('#combat-ally');
  if (c.hasAlly) {
    allyEl.classList.remove('hidden');
    $('#c-ally-hp').style.width = `${(c.allyHp / c.allyMax) * 100}%`;
    $('#c-ally-hp-val').textContent = Math.max(0, Math.round(c.allyHp));
  } else {
    allyEl.classList.add('hidden');
  }
  const logEl = $('#combat-log');
  logEl.innerHTML = c.log.map((l) => `<p class="${l.cls || ''}">${l.msg}</p>`).join('');
  logEl.scrollTop = logEl.scrollHeight;
  const actions = $('#combat-actions');
  actions.innerHTML = '';
  def.abilities.forEach((ab) => {
    if (ab.allyBonus && !c.hasAlly) return;
    const btn = document.createElement('button');
    btn.className = 'btn';
    btn.textContent = ab.name;
    btn.addEventListener('click', () => playerAction(ab));
    actions.appendChild(btn);
  });
}

function rand(min, max) {
  return min + Math.floor(Math.random() * (max - min + 1));
}

function playerAction(ab) {
  const c = state.combat;
  const def = ENCOUNTERS[c.id];
  if (ab.damage) {
    let dmg = rand(ab.damage[0], ab.damage[1]);
    if (ab.allyBonus && c.hasAlly) dmg = Math.round(dmg * 1.35);
    dmg = Math.round(dmg * (1 + state.stats.resonance / 200));
    c.enemyHp -= dmg;
    c.log.push({ msg: `Zero2 uses ${ab.name} — ${dmg} damage.`, cls: 'hit' });
  }
  if (ab.heal) {
    const h = rand(ab.heal[0], ab.heal[1]);
    state.stats.integrity = clamp(state.stats.integrity + h, 0, 100);
    c.log.push({ msg: `Zero2 uses ${ab.name} — recovers ${h} integrity.`, cls: 'heal' });
  }
  if (ab.selfHarm) {
    state.stats.integrity = clamp(state.stats.integrity - ab.selfHarm, 0, 100);
    c.log.push({ msg: `Overload feedback — ${ab.selfHarm} integrity lost.`, cls: 'hit' });
  }
  if (c.enemyHp <= 0) {
    c.log.push({ msg: `${def.name} neutralized.`, cls: 'system' });
    renderCombat();
    setTimeout(() => finishCombat(true), 900);
    return;
  }
  if (c.hasAlly && c.allyHp > 0 && Math.random() > 0.35) {
    const ad = rand(8, 14);
    c.enemyHp -= ad;
    c.log.push({ msg: `De'juir intercepts — ${ad} damage.`, cls: 'system' });
  }
  if (c.enemyHp <= 0) {
    c.log.push({ msg: `${def.name} neutralized.`, cls: 'system' });
    renderCombat();
    setTimeout(() => finishCombat(true), 900);
    return;
  }
  const atk = def.enemyAi[rand(0, def.enemyAi.length - 1)];
  let ed = rand(atk.damage[0], atk.damage[1]);
  ed = Math.round(ed * (1 - state.stats.resonance / 250));
  if (c.hasAlly && c.allyHp > 0 && Math.random() > 0.5) {
    c.allyHp -= Math.round(ed * 0.6);
    state.stats.integrity = clamp(state.stats.integrity - Math.round(ed * 0.4), 0, 100);
    c.log.push({ msg: `${def.name} uses ${atk.name} — shared across tether.`, cls: 'hit' });
  } else {
    state.stats.integrity = clamp(state.stats.integrity - ed, 0, 100);
    c.log.push({ msg: `${def.name} uses ${atk.name} — ${ed} damage.`, cls: 'hit' });
  }
  updateHUD();
  renderCombat();
  if (state.stats.integrity <= 0) {
    c.log.push({ msg: 'Integrity critical. Chassis failing…', cls: 'hit' });
    renderCombat();
    setTimeout(() => finishCombat(false), 1000);
  }
}

function finishCombat(won) {
  const c = state.combat;
  const def = ENCOUNTERS[c.id];
  state.combat = null;
  if (!won) {
    state.stats.integrity = 15;
    state.stats.continuity = clamp(state.stats.continuity - 15, 0, 100);
  }
  showScreen('game');
  showNode(def.onWin);
}

function triggerEnding(id) {
  const e = ENDINGS[id];
  state.ending = id;
  showScreen('ending');
  $('#ending-tag').textContent = e.tag;
  $('#ending-title').textContent = e.title;
  $('#ending-body').textContent = e.body;
}

function saveGame() {
  const payload = { nodeId: state.nodeId, stats: state.stats, flags: state.flags, codex: state.codex };
  localStorage.setItem(SAVE_KEY, JSON.stringify(payload));
  $('#save-msg').textContent = 'State written.';
  setTimeout(() => { $('#save-msg').textContent = ''; }, 2000);
  refreshContinueBtn();
}

function loadGame() {
  const raw = localStorage.getItem(SAVE_KEY);
  if (!raw) return false;
  try {
    const data = JSON.parse(raw);
    state = defaultState();
    state.nodeId = data.nodeId;
    state.stats = { ...defaultState().stats, ...data.stats };
    state.flags = data.flags || {};
    state.codex = data.codex || [];
    return true;
  } catch {
    return false;
  }
}

function refreshContinueBtn() {
  $('#btn-continue').disabled = !localStorage.getItem(SAVE_KEY);
}

function openMenu() { $('#menu-overlay').classList.remove('hidden'); }
function closeMenu() {
  $('#menu-overlay').classList.add('hidden');
  $('#save-msg').textContent = '';
}
function openCodex() {
  const list = $('#codex-list');
  if (!state.codex.length) {
    list.innerHTML = '<p style="color:var(--frost-dim);font-size:0.85rem;text-align:center;">No fragments recovered yet.</p>';
  } else {
    list.innerHTML = state.codex.map((c) => `<div class="codex-entry"><h4>${c.title}</h4><p>${c.body}</p></div>`).join('');
  }
  $('#codex-overlay').classList.remove('hidden');
}

function newGame() {
  state = defaultState();
  showScreen('game');
  updateHUD();
  showNode('wake_1');
}

function continueGame() {
  if (!loadGame()) return;
  showScreen('game');
  updateHUD();
  showNode(state.nodeId || 'wake_1');
}

$('#btn-new').addEventListener('click', newGame);
$('#btn-continue').addEventListener('click', continueGame);
$('#btn-menu').addEventListener('click', openMenu);
$('#btn-resume').addEventListener('click', closeMenu);
$('#btn-save').addEventListener('click', saveGame);
$('#btn-load').addEventListener('click', () => {
  if (loadGame()) {
    closeMenu();
    showScreen('game');
    updateHUD();
    showNode(state.nodeId || 'wake_1');
  }
});
$('#btn-codex').addEventListener('click', () => { closeMenu(); openCodex(); });
$('#btn-codex-close').addEventListener('click', () => { $('#codex-overlay').classList.add('hidden'); });
$('#btn-quit').addEventListener('click', () => {
  closeMenu();
  showScreen('title');
  refreshContinueBtn();
});
$('#btn-title').addEventListener('click', () => {
  showScreen('title');
  refreshContinueBtn();
});

document.addEventListener('keydown', (ev) => {
  if (state.screen !== 'game') return;
  const choices = [...document.querySelectorAll('.choice-btn')];
  if (choices.length && ev.key >= '1' && ev.key <= '9') {
    const idx = parseInt(ev.key, 10) - 1;
    if (choices[idx]) choices[idx].click();
  }
  if ((ev.key === ' ' || ev.key === 'Enter') && !$('#btn-advance').classList.contains('hidden')) {
    ev.preventDefault();
    $('#btn-advance').click();
  }
});

refreshContinueBtn();
showScreen('title');
